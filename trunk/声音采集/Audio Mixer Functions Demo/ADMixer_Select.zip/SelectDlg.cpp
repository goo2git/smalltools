// SelectDlg.cpp : implementation file
//

#include "stdafx.h"
#include <limits.h>				// ULONG_MAX
#include "Select.h"
#include "SelectDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSelectDlg dialog

CSelectDlg::CSelectDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSelectDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSelectDlg)
	m_bSelect = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_hMixer = NULL;
}

void CSelectDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSelectDlg)
	DDX_Check(pDX, IDC_CHECK, m_bSelect);
	DDX_Text(pDX, IDC_EDIT1, m_strStat1);
	DDX_Text(pDX, IDC_EDIT2, m_strStat2);
	DDX_Text(pDX, IDC_EDIT3, m_strStat3);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSelectDlg, CDialog)
	//{{AFX_MSG_MAP(CSelectDlg)
	ON_WM_DESTROY()
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CHECK, OnSelect)
	ON_MESSAGE(MM_MIXM_CONTROL_CHANGE, OnMixerCtrlChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSelectDlg message handlers

BOOL CSelectDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	if (this->amdInitialize())
	{
		// display the number of mixer devices present in the system
		m_strStat1.Format(IDS_FMTNUMMIXERS, m_nNumMixers);

		// display the information about the first mixer
		m_strStat2.Format(IDS_FMTCAPS,
						  m_mxcaps.szPname, m_mxcaps.cDestinations);

		// get the Control ID, index and the names
		if (this->amdGetMicSelectControl())
		{
			// display the line and control name
			m_strStat3.Format(IDS_FMTNAMES,
							  m_strDstLineName, m_strSelectControlName);

			// display the Microphone Select item name
			this->SetDlgItemText(IDC_CHECK, m_strMicName);

			// get the initial value of the Microphone Select control
			LONG lVal = 0;
			if (this->amdGetMicSelectValue(lVal))
			{
				// lVal may be zero or nonzero.
				// m_bSelect needs to be 0 or 1 in order for DDX_Check to work.
				m_bSelect = (lVal != 0);
			}
			else
			{
				ASSERT(FALSE);
			}
		}
		else
		{
			VERIFY(m_strStat3.LoadString(IDS_NOCONTROL));

			// disable the checkbox
			CWnd *const pWndCheck = this->GetDlgItem(IDC_CHECK);
			if (pWndCheck != NULL)
			{
				pWndCheck->EnableWindow(FALSE);
			}
			else
			{
				ASSERT(FALSE);
			}
		}

		VERIFY(this->UpdateData(FALSE));
	}
	else
	{
		ASSERT(FALSE);
	}
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSelectDlg::OnDestroy() 
{
	VERIFY(this->amdUninitialize());

	CDialog::OnDestroy();
}

void CSelectDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSelectDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSelectDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSelectDlg::OnSelect() 
{
#ifdef _DEBUG
	// This function should be called only if the control exists.
	CWnd *const pWndCheck = this->GetDlgItem(IDC_CHECK);
	if (pWndCheck != NULL)
	{
		ASSERT(pWndCheck->IsWindowEnabled());
	}
	else
	{
		ASSERT(FALSE);
	}
#endif

	// set the Microphone Select value according to the state of the check box
	m_bSelect = !m_bSelect;
	if (!this->amdSetMicSelectValue(m_bSelect))
	{
		// could not change it (maybe MUX), get the current state
		this->OnMixerCtrlChange(reinterpret_cast<WPARAM>(m_hMixer),
								static_cast<LPARAM>(m_dwSelectControlID));
	}
}

LRESULT CSelectDlg::OnMixerCtrlChange(WPARAM wParam, LPARAM lParam)
{
	if (reinterpret_cast<HMIXER>(wParam) == m_hMixer &&
		static_cast<DWORD>(lParam) == m_dwSelectControlID)
	{
#ifdef _DEBUG
		// This function should be called only if the control exists.
		CWnd *const pWndCheck = this->GetDlgItem(IDC_CHECK);
		if (pWndCheck != NULL)
		{
			ASSERT(pWndCheck->IsWindowEnabled());
		}
		else
		{
			ASSERT(FALSE);
		}
#endif

		// The state of the Microphone Select control has changed. Refresh it.
		LONG lVal = 0;
		if (this->amdGetMicSelectValue(lVal))
		{
			// lVal may be zero or nonzero.
			// m_bSelect needs to be 0 or 1 in order for DDX_Check to work.
			m_bSelect = (lVal != 0);

			VERIFY(this->UpdateData(FALSE));
		}
		else
		{
			ASSERT(FALSE);
		}
	}

	return 0;
}

BOOL CSelectDlg::amdInitialize()
{
	ASSERT(m_hMixer == NULL);

	// get the number of mixer devices present in the system
	m_nNumMixers = ::mixerGetNumDevs();

	m_hMixer = NULL;
	::ZeroMemory(&m_mxcaps, sizeof(MIXERCAPS));

	m_strDstLineName.Empty();
	m_strSelectControlName.Empty();
	m_strMicName.Empty();
	m_dwControlType = 0;
	m_dwSelectControlID = 0;
	m_dwMultipleItems = 0;
	m_dwIndex = ULONG_MAX;

	// open the first mixer
	// A "mapper" for audio mixer devices does not currently exist.
	if (m_nNumMixers != 0)
	{
		if (::mixerOpen(&m_hMixer,
						0,
						reinterpret_cast<DWORD>(this->GetSafeHwnd()),
						NULL,
						MIXER_OBJECTF_MIXER | CALLBACK_WINDOW)
			!= MMSYSERR_NOERROR)
		{
			return FALSE;
		}

		if (::mixerGetDevCaps(reinterpret_cast<UINT>(m_hMixer),
							  &m_mxcaps, sizeof(MIXERCAPS))
			!= MMSYSERR_NOERROR)
		{
			return FALSE;
		}
	}

	return TRUE;
}

BOOL CSelectDlg::amdUninitialize()
{
	BOOL bSucc = TRUE;

	if (m_hMixer != NULL)
	{
		bSucc = (::mixerClose(m_hMixer) == MMSYSERR_NOERROR);
		m_hMixer = NULL;
	}

	return bSucc;
}

BOOL CSelectDlg::amdGetMicSelectControl()
{
	if (m_hMixer == NULL)
	{
		return FALSE;
	}

	// get dwLineID
	MIXERLINE mxl;
	mxl.cbStruct = sizeof(MIXERLINE);
	mxl.dwComponentType = MIXERLINE_COMPONENTTYPE_DST_WAVEIN;
	if (::mixerGetLineInfo(reinterpret_cast<HMIXEROBJ>(m_hMixer),
						   &mxl,
						   MIXER_OBJECTF_HMIXER |
						   MIXER_GETLINEINFOF_COMPONENTTYPE)
		!= MMSYSERR_NOERROR)
	{
		return FALSE;
	}

	// get dwControlID
	MIXERCONTROL mxc;
	MIXERLINECONTROLS mxlc;
	m_dwControlType = MIXERCONTROL_CONTROLTYPE_MIXER;
	mxlc.cbStruct = sizeof(MIXERLINECONTROLS);
	mxlc.dwLineID = mxl.dwLineID;
	mxlc.dwControlType = m_dwControlType;
	mxlc.cControls = 1;
	mxlc.cbmxctrl = sizeof(MIXERCONTROL);
	mxlc.pamxctrl = &mxc;
	if (::mixerGetLineControls(reinterpret_cast<HMIXEROBJ>(m_hMixer),
							   &mxlc,
							   MIXER_OBJECTF_HMIXER |
							   MIXER_GETLINECONTROLSF_ONEBYTYPE)
		!= MMSYSERR_NOERROR)
	{
		// no mixer, try MUX
		m_dwControlType = MIXERCONTROL_CONTROLTYPE_MUX;
		mxlc.cbStruct = sizeof(MIXERLINECONTROLS);
		mxlc.dwLineID = mxl.dwLineID;
		mxlc.dwControlType = m_dwControlType;
		mxlc.cControls = 1;
		mxlc.cbmxctrl = sizeof(MIXERCONTROL);
		mxlc.pamxctrl = &mxc;
		if (::mixerGetLineControls(reinterpret_cast<HMIXEROBJ>(m_hMixer),
								   &mxlc,
								   MIXER_OBJECTF_HMIXER |
								   MIXER_GETLINECONTROLSF_ONEBYTYPE)
			!= MMSYSERR_NOERROR)
		{
			return FALSE;
		}
	}

	// store dwControlID, cMultipleItems
	m_strDstLineName = mxl.szName;
	m_strSelectControlName = mxc.szName;
	m_dwSelectControlID = mxc.dwControlID;
	m_dwMultipleItems = mxc.cMultipleItems;

	if (m_dwMultipleItems == 0)
	{
		return FALSE;
	}

	// get the index of the Microphone Select control
	MIXERCONTROLDETAILS_LISTTEXT *pmxcdSelectText =
		new MIXERCONTROLDETAILS_LISTTEXT[m_dwMultipleItems];

	if (pmxcdSelectText != NULL)
	{
		MIXERCONTROLDETAILS mxcd;
		mxcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
		mxcd.dwControlID = m_dwSelectControlID;
		mxcd.cChannels = 1;
		mxcd.cMultipleItems = m_dwMultipleItems;
		mxcd.cbDetails = sizeof(MIXERCONTROLDETAILS_LISTTEXT);
		mxcd.paDetails = pmxcdSelectText;
		if (::mixerGetControlDetails(reinterpret_cast<HMIXEROBJ>(m_hMixer),
									 &mxcd,
									 MIXER_OBJECTF_HMIXER |
									 MIXER_GETCONTROLDETAILSF_LISTTEXT)
			== MMSYSERR_NOERROR)
		{
			// determine which controls the Microphone source line
			for (DWORD dwi = 0; dwi < m_dwMultipleItems; dwi++)
			{
				// get the line information
				MIXERLINE mxl;
				mxl.cbStruct = sizeof(MIXERLINE);
				mxl.dwLineID = pmxcdSelectText[dwi].dwParam1;
				if (::mixerGetLineInfo(reinterpret_cast<HMIXEROBJ>(m_hMixer),
									   &mxl,
									   MIXER_OBJECTF_HMIXER |
									   MIXER_GETLINEINFOF_LINEID)
					== MMSYSERR_NOERROR &&
					mxl.dwComponentType == MIXERLINE_COMPONENTTYPE_SRC_MICROPHONE)
				{
					// found, dwi is the index.
					m_dwIndex = dwi;
					m_strMicName = pmxcdSelectText[dwi].szName;
					break;
				}
			}

			if (dwi >= m_dwMultipleItems)
			{
				// could not find it using line IDs, some mixer drivers have
				// different meaning for MIXERCONTROLDETAILS_LISTTEXT.dwParam1.
				// let's try comparing the item names.
				for (dwi = 0; dwi < m_dwMultipleItems; dwi++)
				{
					if (::lstrcmp(pmxcdSelectText[dwi].szName,
								  _T("Microphone")) == 0)
					{
						// found, dwi is the index.
						m_dwIndex = dwi;
						m_strMicName = pmxcdSelectText[dwi].szName;
						break;
					}
				}
			}
		}

		delete []pmxcdSelectText;
	}

	return m_dwIndex < m_dwMultipleItems;
}

BOOL CSelectDlg::amdGetMicSelectValue(LONG &lVal) const
{
	if (m_hMixer == NULL ||
		m_dwMultipleItems == 0 ||
		m_dwIndex >= m_dwMultipleItems)
	{
		return FALSE;
	}

	BOOL bRetVal = FALSE;

	MIXERCONTROLDETAILS_BOOLEAN *pmxcdSelectValue =
		new MIXERCONTROLDETAILS_BOOLEAN[m_dwMultipleItems];

	if (pmxcdSelectValue != NULL)
	{
		MIXERCONTROLDETAILS mxcd;
		mxcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
		mxcd.dwControlID = m_dwSelectControlID;
		mxcd.cChannels = 1;
		mxcd.cMultipleItems = m_dwMultipleItems;
		mxcd.cbDetails = sizeof(MIXERCONTROLDETAILS_BOOLEAN);
		mxcd.paDetails = pmxcdSelectValue;
		if (::mixerGetControlDetails(reinterpret_cast<HMIXEROBJ>(m_hMixer),
									 &mxcd,
									 MIXER_OBJECTF_HMIXER |
									 MIXER_GETCONTROLDETAILSF_VALUE)
			== MMSYSERR_NOERROR)
		{
			lVal = pmxcdSelectValue[m_dwIndex].fValue;
			bRetVal = TRUE;
		}

		delete []pmxcdSelectValue;
	}

	return bRetVal;
}

BOOL CSelectDlg::amdSetMicSelectValue(LONG lVal) const
{
	if (m_hMixer == NULL ||
		m_dwMultipleItems == 0 ||
		m_dwIndex >= m_dwMultipleItems)
	{
		return FALSE;
	}

	BOOL bRetVal = FALSE;

	// get all the values first
	MIXERCONTROLDETAILS_BOOLEAN *pmxcdSelectValue =
		new MIXERCONTROLDETAILS_BOOLEAN[m_dwMultipleItems];

	if (pmxcdSelectValue != NULL)
	{
		MIXERCONTROLDETAILS mxcd;
		mxcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
		mxcd.dwControlID = m_dwSelectControlID;
		mxcd.cChannels = 1;
		mxcd.cMultipleItems = m_dwMultipleItems;
		mxcd.cbDetails = sizeof(MIXERCONTROLDETAILS_BOOLEAN);
		mxcd.paDetails = pmxcdSelectValue;
		if (::mixerGetControlDetails(reinterpret_cast<HMIXEROBJ>(m_hMixer),
									 &mxcd,
									 MIXER_OBJECTF_HMIXER |
									 MIXER_GETCONTROLDETAILSF_VALUE)
			== MMSYSERR_NOERROR)
		{
			ASSERT(m_dwControlType == MIXERCONTROL_CONTROLTYPE_MIXER ||
				   m_dwControlType == MIXERCONTROL_CONTROLTYPE_MUX);

			// MUX restricts the line selection to one source line at a time.
			if (lVal != 0 && m_dwControlType == MIXERCONTROL_CONTROLTYPE_MUX)
			{
				::ZeroMemory(pmxcdSelectValue,
							 m_dwMultipleItems * sizeof(MIXERCONTROLDETAILS_BOOLEAN));
			}

			// set the Microphone value
			pmxcdSelectValue[m_dwIndex].fValue = lVal;

			mxcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
			mxcd.dwControlID = m_dwSelectControlID;
			mxcd.cChannels = 1;
			mxcd.cMultipleItems = m_dwMultipleItems;
			mxcd.cbDetails = sizeof(MIXERCONTROLDETAILS_BOOLEAN);
			mxcd.paDetails = pmxcdSelectValue;
			if (::mixerSetControlDetails(reinterpret_cast<HMIXEROBJ>(m_hMixer),
										 &mxcd,
										 MIXER_OBJECTF_HMIXER |
										 MIXER_SETCONTROLDETAILSF_VALUE)
				== MMSYSERR_NOERROR)
			{
				bRetVal = TRUE;
			}
		}

		delete []pmxcdSelectValue;
	}

	return bRetVal;
}
