See Changelog.txt

Bugs/Comments/Requests/Improvements/Suggestions email me at
llewellyn@pritchard.org