#pragma once

#include "resource.h"
#include "MyDirectSound.h"

#ifndef INCLUDE_DIRECTSOUND
#define INCLUDE_DIRECTSOUND

#define FFT_SIZE			512
#define FFT_SAMPLE_SIZE		2048
#define IDT_TIMER			19790913

#define SPECTRUM_WIDTH		512
#define SPECTRUM_HEIGHT		150
#define SPECTRUM_DECAY		0.05
#define SPECTRUM_BANDS		90
#define SPECTRUM_DELAY		20

TCHAR szDisplaySamples[32];
FLOAT floatSamples[FFT_SAMPLE_SIZE];
FLOAT floatMag[FFT_SAMPLE_SIZE>>1];
FLOAT floatOldMag[FFT_SAMPLE_SIZE>>1];
INT   intPeaks[SPECTRUM_BANDS];
INT	  intPeaksDelay[SPECTRUM_BANDS];
PLAY_MOD* gp_playmod = NULL;

//prototype define
void DrawSpectrum(HWND hwnd, float* fftData);
void DrawSpectrumBar(HDC hdc, int x, int y, int width, int height);
DWORD WINAPI FFTThreadProc(LPVOID lpParam);
HRESULT CALLBACK GetSamples(LPBYTE lpDesBuf, const DWORD dwRequiredSamples, DWORD &dwRetSamples, LPVOID lpData);
void CALLBACK TimerProc(UINT uTimerID, UINT uMsg, DWORD dwUser, DWORD dw1, DWORD dw2);
VOID CALLBACK		WindowTimerProc(HWND hwnd,UINT message,UINT idTimer,DWORD dwTime);
//prototype define

#define WIDTH(rc) ((rc).right-(rc.left))
#define HEIGHT(rc) ((rc).bottom-(rc.top))
void DrawSpectrum_BAK(HWND hwnd, float* fftData)
{
	if(fftData == NULL)
		return;	

	HDC hdc = GetWindowDC(hwnd);
	SetBkMode(hdc, TRANSPARENT);

	HPEN hpen, hpenOld;
	HBRUSH hbrush, hbrushOld;
	RECT rect;

	rect.left = 4;
	rect.top = 23;
	rect.right = rect.left+SPECTRUM_WIDTH;
	rect.bottom = rect.top+SPECTRUM_HEIGHT;

	// Create a green pen.
	hpen = CreatePen(PS_SOLID, 1, RGB(0, 255, 0));
	// Create a red brush.
	hbrush = CreateSolidBrush(RGB(0, 0, 0));

	// Select the new pen and brush, and then draw.
	hpenOld = (HPEN)SelectObject(hdc, hpen);
	hbrushOld = (HBRUSH)SelectObject(hdc, hbrush);
	Rectangle(hdc, rect.left, rect.top, rect.right, rect.bottom);

	int maxFreq = FFT_SIZE / 2;
	int height = 0;
	int maxHeight = SPECTRUM_HEIGHT;

	for(int i=0;i<maxFreq;i++)
	{
		if(fftData[i] <= 0.0)
			height = rect.bottom-2;
		else {
			height = (int)(fftData[i]*maxHeight);
			if(height > maxHeight)
				height = rect.top+1;
			else
				height = rect.top + (maxHeight-height);
		}

		MoveToEx(hdc, rect.left + 2*i, rect.bottom-2, NULL);
		LineTo(hdc, rect.left + 2*i, height);
	}

	// Do not forget to clean up.
	SelectObject(hdc, hpenOld);
	DeleteObject(hpen);
	SelectObject(hdc, hbrushOld);
	DeleteObject(hbrush);
	ReleaseDC(hwnd, hdc);
}

void DrawSpectrum(HWND hwnd, float* fftData)
{
	if(fftData == NULL)
		return;	

	HDC hdc = GetWindowDC(hwnd);
	SetBkMode(hdc, TRANSPARENT);

	HPEN hpen, hpenOld;
	HBRUSH hbrush, hbrushOld;
	HBRUSH hbrush1, hbrushOld1;
	RECT rect;

	rect.left = 4;
	rect.top = 23;
	rect.right = rect.left+SPECTRUM_WIDTH;
	rect.bottom = rect.top+SPECTRUM_HEIGHT;

	// Create a green pen.
	hpen = CreatePen(PS_SOLID, 1, RGB(0, 255, 0));
	// Create a red brush.
	hbrush = CreateSolidBrush(RGB(0, 0, 0));
	hbrush1 = CreateSolidBrush(RGB(125, 125, 125));

	// Select the new pen and brush, and then draw.
	hpenOld = (HPEN)SelectObject(hdc, hpen);
	hbrushOld = (HBRUSH)SelectObject(hdc, hbrush);
	hbrushOld1 = (HBRUSH)SelectObject(hdc, hbrush1);
	Rectangle(hdc, rect.left, rect.top, rect.right, rect.bottom);

	int maxFreq = FFT_SIZE / 2;
	int height = 0;
	int maxHeight = SPECTRUM_HEIGHT;

	float c = 0;
	float floatFrrh = 1.0;
	float floatDecay = (float)SPECTRUM_DECAY;
	float floatSadFrr = (floatFrrh*floatDecay);
	float floatBandWidth = ((float)SPECTRUM_WIDTH/(float)SPECTRUM_BANDS);
	float floatMultiplier = 2.0;

	//CString xx;
	RECT r;
	for(int a=0, band=0; band < SPECTRUM_BANDS; a+=(int)floatMultiplier, band++)
	{
		float wFs = 0;

		// -- Average out nearest bands.
		for (int b = 0; b < floatMultiplier; b++) {
			wFs += fftData[a + b];
		}

		// -- Log filter.
		wFs = (wFs * (float) log((float)(band + 2)));
		//xx.Format(_T("%1.4f\n"), wFs);
		//OutputDebugString(xx);
		if (wFs > 1.0f) {
			wFs = 1.0f;
		}

		// -- Compute SA decay...
		if (wFs >= (floatOldMag[a] - floatSadFrr)) {
			floatOldMag[a] = wFs;
		} else {
			floatOldMag[a] -= floatSadFrr;
			if (floatOldMag[a] < 0) {
				floatOldMag[a] = 0;
			}
			wFs = floatOldMag[a];
		}

		r.left = rect.left + (int)c + 1;
		r.right = r.left + (int)(floatBandWidth-1);
		r.top = SPECTRUM_HEIGHT - (int)(wFs*SPECTRUM_HEIGHT);
		if(r.top < rect.top)
			r.top = rect.top + 2;

		r.top += 22;
		r.bottom = rect.bottom-2;		

		FillRect(hdc, &r, hbrushOld1);

		int height = HEIGHT(r);
		if(height > intPeaks[band])
		{
			intPeaks[band] = height;
			intPeaksDelay[band] = SPECTRUM_DELAY;
		}
		else
		{
			intPeaksDelay[band]--;
			if (intPeaksDelay[band] < 0) {
				intPeaks[band]--;
			}

			if (intPeaks[band] < 0) {
				intPeaks[band] = 0;
			}
		}

		r.top -= intPeaks[band];
		if(r.top < rect.top)
			r.top = rect.top + 2;

		r.top += 22;
		if(r.top >= rect.bottom)
			r.top = rect.bottom - 2;

		r.bottom = r.top + 1;
		FillRect(hdc, &r, hbrushOld1);

		c += floatBandWidth;
	}

	// Do not forget to clean up.
	SelectObject(hdc, hpenOld);
	DeleteObject(hpen);
	SelectObject(hdc, hbrushOld);
	DeleteObject(hbrush);
	SelectObject(hdc, hbrushOld1);
	DeleteObject(hbrush1);
	ReleaseDC(hwnd, hdc);

	Sleep(20);
}

void DrawSpectrumBar(HDC hdc, int pX, int pY, int pWidth, int pHeight)
{
	Rectangle(hdc, pX, pY, pX+pWidth, pY+pHeight);
}

DWORD WINAPI FFTThreadProc(LPVOID lpParam)
{
	PLAY_MOD* playmod = (PLAY_MOD*)lpParam;
	while(playmod->iStatus == PLAY_STATUS_PLAY)
	{
		DrawSpectrum(playmod->hWndMain, playmod->pFFTData);
	}

	return 0;
}

HRESULT CALLBACK GetSamples(LPBYTE lpDesBuf, const DWORD dwRequiredSamples, DWORD &dwRetSamples, LPVOID lpData)
{
	PLAY_MOD* playmod = (PLAY_MOD*)lpData;
	DWORD dwRequiredBytes = 0, dwRetBytes = 0;
	WAVEFORMATEX *pWFE = playmod->pWFX;
	dwRequiredBytes = dwRequiredSamples*pWFE->nBlockAlign;
	playmod->pWaveFile->Read(lpDesBuf, dwRequiredBytes, &dwRetBytes);
	dwRetSamples = dwRetBytes/pWFE->nBlockAlign;
	return 0;
}

void CALLBACK TimerProc(UINT uTimerID, UINT uMsg, DWORD dwUser, DWORD dw1, DWORD dw2)
{
	PLAY_MOD* playmod = (PLAY_MOD*)dwUser;

	DWORD dwCurPlayPos = 0;
	DWORD dwSamplesPlayed = playmod->pMyDS->GetSamplesPlayed(&dwCurPlayPos);
	DWORD dw2SecondByteSize = 2*playmod->pWFX->nAvgBytesPerSec;

	if(dwSamplesPlayed >= playmod->dwTotalSamples)
	{
		playmod->pMyDS->Stop();
		timeKillEvent(playmod->mmTimerID);
		playmod->mmTimerID = 0;
		playmod->iStatus = PLAY_STATUS_STOP;
		memset(floatMag, 0, FFT_SAMPLE_SIZE/2);
	}
	else
	{
		LPBYTE lpAudioBuffer = playmod->pMyDS->GetSampleDataBuffer();
		if(lpAudioBuffer == NULL)
			return;

		float left, right;
		for(int i=0;i<FFT_SAMPLE_SIZE;i++) {
			if(dwCurPlayPos > dw2SecondByteSize)
				dwCurPlayPos -= dw2SecondByteSize;

			left = (float)((lpAudioBuffer[dwCurPlayPos+1] << 8) + lpAudioBuffer[dwCurPlayPos+0])/32767;
			right = (float)((lpAudioBuffer[dwCurPlayPos+3] << 8) + lpAudioBuffer[dwCurPlayPos+2])/32767;
			floatSamples[i] = (left+right)/2;
			dwCurPlayPos+=4;
		}

		FFT* fft = (FFT*)playmod->fft;
		float* lpFloatFFTData = fft->calculate(floatSamples, FFT_SAMPLE_SIZE);
		memcpy(floatMag, lpFloatFFTData, FFT_SAMPLE_SIZE/2);
		SendMessage(playmod->hWndMain, WM_PAINT+913, (WPARAM)0, (LPARAM)13);
	}
}

VOID CALLBACK WindowTimerProc(HWND hwnd, UINT message, UINT idTimer, DWORD dwTime)
{
	//if window is not minimized
	if(!IsIconic(hwnd) && gp_playmod != NULL)
	{
		if(gp_playmod->iStatus != PLAY_STATUS_PLAY)
			return;

		DWORD dwCurPlayPos = 0;
		DWORD dwSamplesPlayed = gp_playmod->pMyDS->GetSamplesPlayed(&dwCurPlayPos);
		DWORD dw2SecondByteSize = 2*gp_playmod->pWFX->nAvgBytesPerSec;

		LPBYTE lpAudioBuffer = gp_playmod->pMyDS->GetSampleDataBuffer();
		if(lpAudioBuffer == NULL)
			return;

		float left, right;
		for(int i=0;i<FFT_SAMPLE_SIZE;i++) {
			if(dwCurPlayPos > dw2SecondByteSize)
				dwCurPlayPos -= dw2SecondByteSize;

			left = (float)((lpAudioBuffer[dwCurPlayPos+1] << 8) + lpAudioBuffer[dwCurPlayPos+0])/32767;
			right = (float)((lpAudioBuffer[dwCurPlayPos+3] << 8) + lpAudioBuffer[dwCurPlayPos+2])/32767;
			floatSamples[i] = (left+right)/2;
			dwCurPlayPos+=4;
		}

		FFT* fft = (FFT*)gp_playmod->fft;
		float* lpFloatFFTData = fft->calculate(floatSamples, FFT_SAMPLE_SIZE);
		memcpy(floatMag, lpFloatFFTData, FFT_SAMPLE_SIZE/2);

		DrawSpectrum(gp_playmod->hWndMain, gp_playmod->pFFTData);
	}
}

#endif
