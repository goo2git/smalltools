// MyRecordDlg.h : header file
//

#if !defined(AFX_MYRECORDDLG_H__9E469F6E_B0E1_47BB_898C_309BA59B2CC5__INCLUDED_)
#define AFX_MYRECORDDLG_H__9E469F6E_B0E1_47BB_898C_309BA59B2CC5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMyRecordDlg dialog

class CMyRecordDlg : public CDialog
{
// Construction
public:
	CMyRecordDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMyRecordDlg)
	enum { IDD = IDD_MYRECORD_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyRecordDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMyRecordDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonStart();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	DWORD RecordWAVEFile(DWORD dwMilliSeconds);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYRECORDDLG_H__9E469F6E_B0E1_47BB_898C_309BA59B2CC5__INCLUDED_)
