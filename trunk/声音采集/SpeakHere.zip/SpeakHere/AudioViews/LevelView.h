//
//  LevelView.h
//  aqTouch3
//
//  Created by Mehul Trivedi on 5/23/08.
//  Copyright 2008 AngryAudio. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LevelView : UIView {
	IBOutlet AQLevelMeter	*_lvlMeterL_in;
	IBOutlet AQLevelMeter	*_lvlMeterR_in;
}

@end
