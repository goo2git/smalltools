//
//  LevelView.m
//  aqTouch3
//
//  Created by Mehul Trivedi on 5/23/08.
//  Copyright 2008 AngryAudio. All rights reserved.
//

#import "LevelView.h"


@implementation LevelView


- (id)initWithFrame:(CGRect)frame {
	if (self = [super initWithFrame:frame]) {
		// Initialization code
	}
	return self;
}


- (void)drawRect:(CGRect)rect {
	// Drawing code
}


- (void)dealloc {
	[super dealloc];
}


@end
