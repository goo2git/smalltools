// CPeak.h: interface for the CPeak class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CPEAK_H__EA90B675_44B8_11D3_9A58_0080C605ADA4__INCLUDED_)
#define AFX_CPEAK_H__EA90B675_44B8_11D3_9A58_0080C605ADA4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define TOTALBUFFER 128000

class CPeak  
{
public:
	CPeak();
	virtual ~CPeak();


	// Variables
	WORD*	m_lpPeaks;

	// pointer to our data
	WORD*	m_lpLPeak;
	WORD*	m_lpRPeak;
	
	long	m_lLTotal;
	long	m_lRTotal;
	long	m_lTotalSamples;


	// other stuff
	BOOL	m_bPeaksInitialized;
	WORD	m_lLCurrentPeak;
	WORD	m_lRCurrentPeak;
	long	m_lSampleInterval;
	long	m_lCounter;
	long	m_lTotalPeaks;
	CFile	m_fFile;
	BOOL	m_bFileOpen;
	// Funcs
	void	CheckAgainstCurrentPeaks			(WORD* lpLSample,WORD* lpRSample);
	void	SetPeaks							(WORD* lpLPeak,WORD* lpRPeak);
	void	ZeroOut								();
	void	IncreaseCounterAndUpdate			();
	void	Initialize							(long lInterval,CString sFilename);
	void	WriteOutBuffer						();
	void	EmptyOutBuffer						();
	void	Process								(WORD* lpLSample,WORD* lpRSample);
};

#endif // !defined(AFX_CPEAK_H__EA90B675_44B8_11D3_9A58_0080C605ADA4__INCLUDED_)
