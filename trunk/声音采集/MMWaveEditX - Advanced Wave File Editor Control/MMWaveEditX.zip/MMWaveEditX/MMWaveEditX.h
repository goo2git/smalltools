#if !defined(AFX_MMWAVEEDITX_H__02DAA66B_4ABB_11D3_9A58_0080C605ADA4__INCLUDED_)
#define AFX_MMWAVEEDITX_H__02DAA66B_4ABB_11D3_9A58_0080C605ADA4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// MMWaveEditX.h : main header file for MMWAVEEDITX.DLL

#if !defined( __AFXCTL_H__ )
	#error include 'afxctl.h' before including this file
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMMWaveEditXApp : See MMWaveEditX.cpp for implementation.

class CMMWaveEditXApp : public COleControlModule
{
public:
	BOOL InitInstance();
	int ExitInstance();
};

extern const GUID CDECL _tlid;
extern const WORD _wVerMajor;
extern const WORD _wVerMinor;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MMWAVEEDITX_H__02DAA66B_4ABB_11D3_9A58_0080C605ADA4__INCLUDED)
