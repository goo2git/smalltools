#if !defined(AFX_MMWAVEEDITXPPG_H__02DAA674_4ABB_11D3_9A58_0080C605ADA4__INCLUDED_)
#define AFX_MMWAVEEDITXPPG_H__02DAA674_4ABB_11D3_9A58_0080C605ADA4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// MMWaveEditXPpg.h : Declaration of the CMMWaveEditXPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CMMWaveEditXPropPage : See MMWaveEditXPpg.cpp.cpp for implementation.

class CMMWaveEditXPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CMMWaveEditXPropPage)
	DECLARE_OLECREATE_EX(CMMWaveEditXPropPage)

// Constructor
public:
	CMMWaveEditXPropPage();

// Dialog Data
	//{{AFX_DATA(CMMWaveEditXPropPage)
	enum { IDD = IDD_PROPPAGE_MMWAVEEDITX };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CMMWaveEditXPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MMWAVEEDITXPPG_H__02DAA674_4ABB_11D3_9A58_0080C605ADA4__INCLUDED)
