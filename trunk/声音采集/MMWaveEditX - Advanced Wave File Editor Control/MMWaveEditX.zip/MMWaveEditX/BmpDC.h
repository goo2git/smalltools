// BmpDC.h: interface for the CBmpDC class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BMPDC_H__F0078413_3BFF_11D3_9A58_0080C605ADA4__INCLUDED_)
#define AFX_BMPDC_H__F0078413_3BFF_11D3_9A58_0080C605ADA4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CBmpDC  : public CDC
{
public:
	CBmpDC();
	CBmpDC(CDC* lpDC,CRect rcBounds,BOOL bCopyBkg);
	virtual ~CBmpDC();

	CBitmap		m_bmpTemp;
	CBitmap*	m_lpOldBmp;
};

#endif // !defined(AFX_BMPDC_H__F0078413_3BFF_11D3_9A58_0080C605ADA4__INCLUDED_)
