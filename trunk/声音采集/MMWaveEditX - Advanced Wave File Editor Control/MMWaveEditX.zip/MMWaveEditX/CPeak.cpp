// CPeak.cpp: implementation of the CPeak class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CPeak.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPeak::CPeak()
{
	m_lpPeaks = NULL;
	m_bPeaksInitialized = FALSE;
	m_bFileOpen = FALSE;
}

CPeak::~CPeak()
{
	if(m_lpPeaks != NULL)
		delete m_lpPeaks;

	if(m_bFileOpen == TRUE)
		m_fFile.Close();
}
void CPeak::Initialize(long lInterval,CString sFilename)
{
	if(m_lpPeaks != NULL)
		delete m_lpPeaks;

	m_lSampleInterval = lInterval;
	m_lpPeaks   =		new WORD[TOTALBUFFER];
	m_fFile.Open((LPCTSTR)sFilename,CFile::modeCreate|CFile::modeWrite|CFile::typeBinary);
	m_bFileOpen = TRUE;
	m_bPeaksInitialized = FALSE;
	ZeroOut();
}
void CPeak::CheckAgainstCurrentPeaks(WORD* lpLSample,WORD* lpRSample)
{
//	if(m_bPeaksInitialized == TRUE)
//	{
		m_lLCurrentPeak = *lpLSample;
		m_lRCurrentPeak = *lpRSample;
//	}
//	else
//	{
//		m_bPeaksInitialized = TRUE;
//		m_lLCurrentPeak = *lpLSample;
//		m_lRCurrentPeak = *lpRSample;
//	}


}
void CPeak::Process(WORD* lpLSample,WORD* lpRSample)
{
	if(m_bPeaksInitialized == TRUE)
	{
		if(*lpLSample > m_lLCurrentPeak)
		{
			m_lLCurrentPeak = *lpLSample;
		}
		if(*lpRSample > m_lRCurrentPeak)
		{
			m_lRCurrentPeak = *lpRSample;
		}
	}
	else
	{
		m_bPeaksInitialized = TRUE;
		WORD lTotal = (*lpLSample+m_lLCurrentPeak);
		WORD rTotal = (*lpRSample+m_lRCurrentPeak);

		if(lTotal != 0)
			m_lLCurrentPeak = WORD((lTotal)/2);
		if(rTotal != 0)
			m_lRCurrentPeak = WORD((rTotal)/2);
	}

	// check the counter
	m_lCounter++;

	if(m_lCounter >= m_lSampleInterval)
	{
		*m_lpLPeak = m_lLCurrentPeak;
		*m_lpRPeak = m_lRCurrentPeak;

		m_lpLPeak+=2;
		m_lpRPeak+=2;
		m_lTotalPeaks+=2;
		m_lCounter = 0;
		m_bPeaksInitialized = FALSE;

		if(m_lTotalPeaks == TOTALBUFFER)
			WriteOutBuffer();
	}

}
void CPeak::SetPeaks(WORD* lpLPeak,WORD* lpRPeak)
{
	m_lLCurrentPeak = *lpLPeak;
	m_lRCurrentPeak = *lpRPeak;

}
void CPeak::ZeroOut()
{
	m_lCounter=0;
	m_lTotalSamples = 0;
	m_lTotalPeaks=0;
	m_lpLPeak = &m_lpPeaks[0];
	m_lpRPeak = &m_lpPeaks[1];
}
void CPeak::IncreaseCounterAndUpdate()
{
	m_lCounter++;

	if(m_lCounter >= m_lSampleInterval)
	{
		*m_lpLPeak = m_lLCurrentPeak;
		*m_lpRPeak = m_lRCurrentPeak;

		m_lpLPeak+=2;
		m_lpRPeak+=2;
		m_lTotalPeaks+=2;
		m_lCounter = 0;
		m_bPeaksInitialized = FALSE;
		if(m_lTotalPeaks == TOTALBUFFER)
			WriteOutBuffer();
	}
			
}
void CPeak::WriteOutBuffer()
{
	long lCount = m_lTotalPeaks-2;

	m_fFile.Write(m_lpPeaks,lCount*2);

	m_lTotalPeaks=0;
	m_lpLPeak = &m_lpPeaks[0];
	m_lpRPeak = &m_lpPeaks[1];
}
void CPeak::EmptyOutBuffer()
{
	if(m_lTotalPeaks > 0)
	{
		long lCount = ( (m_lTotalPeaks-2)*2);

		m_fFile.Write(m_lpPeaks,lCount);
	}
}