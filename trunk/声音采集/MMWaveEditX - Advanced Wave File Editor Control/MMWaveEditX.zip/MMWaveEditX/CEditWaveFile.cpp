// CEditWaveFile.cpp: implementation of the CEditWaveFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CEditWaveFile.h"
#include "MMWaveEditXCtl.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEditWaveFile::CEditWaveFile()
{
	m_bInitialized = FALSE;
	m_lCurFilePosition = 0;
	m_lTotalLPoints = 0;
	m_lCursorPosition = 0;
	m_lStartOfSelection = -1;
	SetRect(&m_rcLastSelectRect,-1,-1,-1,-1);
	m_bDraggingCursorInSel = FALSE;
}

CEditWaveFile::~CEditWaveFile()
{

}
BOOL CEditWaveFile::InitializeFile(CString sFilename)
{
	CFile fWaveFile;

	m_sWaveFileName = sFilename;

	fWaveFile.Open( (LPCTSTR) sFilename,CFile::modeRead);
	
	fWaveFile.Read(&m_WaveHeader,40);

	m_lTotalFileLength = fWaveFile.GetLength();
	fWaveFile.Close();

	m_lTotalFileLength -=40;
	m_bInitialized = TRUE;
	m_lCurFilePosition = 0;
	m_lTotalLPoints = 0;
	m_lCursorPosition = 0;

	BuildPeakFile16BS();
	m_lpOwnerCtrl->FireMessage("File Loaded");
	return TRUE;
}
void CEditWaveFile::BuildPeakFile8B()
{
}
void CEditWaveFile::BuildPeakFile8BS()
{
}
void CEditWaveFile::BuildPeakFile16B()
{
}
void CEditWaveFile::BuildPeakFile16BS()
{
	long			lCount = 1;
	long			lFileCounter = 0;
	WORD*			lpSamples;
	long			lNumberOfSecondsToBuffer = 16;
	long			lTotalLengthForPrgs = 0;
	CFile			fWaveFile;
	CString			sPeakFile;
	CPeak			PeakFile;
	WORD*			plSample;
	WORD*			prSample;
	BYTE*			lpbSamples;
	BYTE*			lpbEnd;
	WORD			wSamples[256000];

	// yes we are obviously using a peak file
	m_bPeakFileBeingUsed = TRUE;

	if(IsThereACurrentPeakFile() == TRUE)
		return;

	m_lpOwnerCtrl->FireMessage("Building Peaks");
	//m_lpstcStatus->SetWindowText("Building Peaks");

	lpSamples = wSamples;//*2 for stereo


	fWaveFile.Open((LPCTSTR)m_sWaveFileName,CFile::modeRead|CFile::typeBinary);

//	if(m_lpProgress != NULL)
	m_lpOwnerCtrl->FireProgressIndicator(0);
	lTotalLengthForPrgs = fWaveFile.GetLength();
	lTotalLengthForPrgs -= 40;

	// Init Our Peaks..
	sPeakFile = m_sWaveFileName.Left(m_sWaveFileName.GetLength()-3);
	sPeakFile += "mmp";

	PeakFile.Initialize(128,sPeakFile);

	// Move to the PCM data
	fWaveFile.Seek(40,CFile::begin);

	// build the peaks
	lpbSamples = (BYTE*)lpSamples;

	while(lCount > 0)
	{
		lCount = fWaveFile.Read(lpSamples,512000);
	
		lFileCounter +=lCount;  

//		if(m_lpProgress != NULL)
//			m_lpProgress->SetPos(lFileCounter);
	
		m_lpOwnerCtrl->FireProgressIndicator( long( (lFileCounter/float(lTotalLengthForPrgs))*100));

		if(lCount > 0)
		{
			lpbEnd = lpbSamples;
			lpbEnd += lCount;
			// set our pointers to the beginning of the buffer
			plSample = &lpSamples[0];
			prSample = &lpSamples[1];

			while((void*)plSample < (void*)lpbEnd)
			{
				// check all the peaks and update if neccessary]
				PeakFile.CheckAgainstCurrentPeaks(plSample,prSample);
				PeakFile.IncreaseCounterAndUpdate();
				plSample+=2;
				prSample+=2;
			}
			
		}	
		
	}

	// write our whatever is in the buffers
	PeakFile.EmptyOutBuffer();

	m_lMaxZoom = GetMaxZoomFactor16BS(&PeakFile.m_fFile);
	m_lCurrentZoomFactor = long(m_lMaxZoom);
	delete lpSamples;
}
long CEditWaveFile::GetSamplesPerSecond()
{
	if(m_bInitialized == TRUE)
	{
		return unsigned long(m_WaveHeader.nSamplesPerSec);
	}
	else
		return 0;
}
long CEditWaveFile::GetNumberOfChannels()
{
	if(m_bInitialized == TRUE)
	{
		return unsigned long(m_WaveHeader.nChannels);
	}
	else
		return 0;
}
long CEditWaveFile::GetTotalFileLength()
{
	if(m_bInitialized == TRUE)
	{
		return m_lTotalFileLength;
	}
	else
		return 0;
}
BOOL CEditWaveFile::IsThereACurrentPeakFile()
{
	CFileFind	fWavFile;
	CFileFind	fPeakFile;
	CString		sPeakFile;

	sPeakFile = m_sWaveFileName.Left(m_sWaveFileName.GetLength()-3);
	sPeakFile += "mmp";

	if(fPeakFile.FindFile((LPCTSTR)sPeakFile) == TRUE)
	{
		if(fWavFile.FindFile((LPCTSTR)m_sWaveFileName) == TRUE)
		{
			CTime tmPeak;
			CTime tmWav;

			fPeakFile.FindNextFile();
			fWavFile.FindNextFile();

			fPeakFile.GetLastWriteTime(tmPeak);
			fWavFile.GetLastWriteTime(tmWav);

			if(tmPeak > tmWav)
			{
				CFile pkFile;
				pkFile.Open((LPCTSTR)sPeakFile,CFile::modeRead|CFile::typeBinary);

				m_lMaxZoom = GetMaxZoomFactor16BS(&pkFile);
				m_lCurrentZoomFactor = long(m_lMaxZoom);
				m_lLastZoomFactorUsed = m_lCurrentZoomFactor;
				return TRUE;
			}
		}
	}

	return FALSE;
}
long CEditWaveFile::GetMaxZoomFactor16B(CFile* lpFile)
{
	return 0;
}
long CEditWaveFile::GetMaxZoomFactor16BS(CFile* lpFile)
{
	long lTotalSize = lpFile->GetLength();

	float fMaxZoom = float(lTotalSize/4.0);// 4 for stereo channels

	fMaxZoom *= 0.25;

	fMaxZoom /= 128;

	long Zoom = long(fMaxZoom)*128;

	long k;

	long lint = 128;

	for(k=128;k<Zoom;k+=1)
	{
		if(lint > Zoom)
		{
		//	lint /= 2.0;
			break;
		}
		lint *=2;
	}

	return lint;
}
long CEditWaveFile::GetMaxZoomFactor8BS(CFile* lpFile)
{
	return 0;
}
long CEditWaveFile::GetMaxZoomFactor8B(CFile* lpFile)
{
	return 0;
}
void CEditWaveFile::Draw(CDC* lpDC,CRect rcBounds)
{
	if(m_bInitialized == FALSE)
	{
		DrawUnInitialized(lpDC,rcBounds);
		return;
	}

	switch(m_WaveHeader.wBitsPerSample)
	{
		case 8: // 8 Bit Wave File
				if(m_WaveHeader.nChannels ==1)
					Create8BWaveFormBmp(lpDC,rcBounds);
				else
					Create8BSWaveFormBmp(lpDC,rcBounds);
				break;
		case 16: // 16 Bit Wave File
				if(m_WaveHeader.nChannels ==1)
					Create16BWaveFormBmp(lpDC,rcBounds);
				else
					Create16BSWaveFormBmp(lpDC,rcBounds);
				break;
	}
}
void CEditWaveFile::Create16BSWaveFormBmp(CDC* lpDC,CRect rcBounds)
{

	if(m_lCurrentZoomFactor < 128)
	{
		Draw16BSWaveformDirectlyFromFile(lpDC,rcBounds);
		return;
	}

	CFile			pkFile;
	long			lCount =1;
	CRect			rcBmp;
	WORD			wBuffer[64000];// File Buffer
	float			scale;
	float			x = 0;
	CPoint			lPoint;	
	CPoint			rPoint;	
	long			lNumOfPoints = 0;
	WORD*			plSample;
	WORD*			prSample;
	BYTE*			lpbSamples = (BYTE*)wBuffer;
	BYTE*			lpbEnd;
	long			lCounter = 0;
	long			lIntervalCounter = 0;

	CPoint			lptLowest;// = ptTemps[0];
	CPoint			lptHighest;// = ptTemps[0];
	CPoint			rptLowest;// = ptTemps[0];
	CPoint			rptHighest;// = ptTemps[0];

	CString			sPeakFile;
	CRect rcLeft;
	CRect rcRight;
	CRect rcScale= rcBounds;

	rcScale.top = 0;
	rcScale.bottom = m_lpOwnerCtrl->m_lScaleHeight;
	rcScale.right = rcBounds.Width();
	rcScale.left = 0;

	rcLeft = rcBounds;
	rcRight = rcBounds;

	rcLeft.top = rcScale.bottom;
	rcLeft.bottom = rcLeft.top + (rcLeft.Height()/2)-1;
	rcRight.top = rcLeft.bottom+2;
	rcLeft.left = 0;
	rcRight.left = 0;
	rcLeft.right = rcBounds.Width();
	rcRight.right = rcBounds.Width();
	rcRight.bottom = rcRight.top+rcLeft.Height();

	rcBmp.left = 0;
	rcBmp.right = rcBounds.Width();
	rcBmp.top = 0;
	rcBmp.bottom = rcBounds.Height();

	lpDC->FillSolidRect(&rcBmp,m_lpOwnerCtrl->GetBackColor());

	scale = 65535 / float(rcLeft.Height());



	if(m_lLastZoomFactorUsed != m_lCurrentZoomFactor || m_lTotalLPoints == 0)
	{
		m_lPoints.clear();
		m_rPoints.clear();
		m_lTotalLPoints = 0;

		m_lLastZoomFactorUsed = m_lCurrentZoomFactor;
		// create the peakfilename
		sPeakFile = m_sWaveFileName.Left(m_sWaveFileName.GetLength()-3);
		sPeakFile += "mmp";
		
		// Now draw the file...
		pkFile.Open((LPCTSTR)sPeakFile,CFile::modeRead|CFile::typeBinary);
		//pkFile.Seek(m_lCurFilePosition*2,CFile::begin);
		while(lCount >0)
		{
			lCount = pkFile.Read((void*)wBuffer,128000);

			if(lCount > 0)
			{

				lpbEnd = lpbSamples;
				lpbEnd += lCount;
				// set our pointers to the beginning of the buffer
				plSample = &wBuffer[0];
				prSample = &wBuffer[1];

				while((void*)plSample < (void*)lpbEnd)
				{
					*plSample +=32767;
					*prSample +=32767;


					lPoint.y = ( (int)*plSample / scale );
					lPoint.y += rcLeft.top;
					lPoint.x = int(x);//+rcBounds.left;

					rPoint.y = ( (int)*prSample / scale );
					rPoint.y += rcRight.top;
					rPoint.x = int(x);//+rcBounds.left;


					if(lIntervalCounter > 0)
					{
						if(lPoint.y < lptHighest.y)
							lptHighest = lPoint;
						if(lPoint.y > lptLowest.y)
							lptLowest = lPoint;

						if(rPoint.y < rptHighest.y)
							rptHighest = rPoint;
						if(rPoint.y > rptLowest.y)
							rptLowest = rPoint;
					}
					else
					{
						lptLowest = lPoint;
						lptHighest = lPoint;
						rptLowest = rPoint;
						rptHighest = rPoint;
					}

					lIntervalCounter++;

					if(lIntervalCounter == m_lCurrentZoomFactor/128)
					{
						m_lPoints.push_back(lptLowest);
						m_lPoints.push_back(lptHighest);
						m_rPoints.push_back(rptLowest);
						m_rPoints.push_back(rptHighest);

						m_lTotalLPoints+=2;

						x+=1;

						lIntervalCounter=0;
					}
					plSample +=2;
					prSample +=2;
				}
			}
		}
		pkFile.Close();
	}
	if(m_lCurFilePosition > m_lTotalLPoints)
		m_lCurFilePosition = m_lTotalLPoints;

	long i;
	long lindex;// = m_lCurFilePosition;

	// draw the DB Lines
	Draw16BScale(lpDC,rcScale,scale);
	Draw16BSdbLine(lpDC,rcLeft,scale);
	Draw16BSdbLine(lpDC,rcRight,scale);

	CPen dbpen (PS_SOLID, 0,m_lpOwnerCtrl->clr_Waveform);
	CPen divpen (PS_SOLID, 0,m_lpOwnerCtrl->clr_Divider);

	CPen* lpOldPen = lpDC->SelectObject(&divpen);

	// draw dividers
	lpDC->MoveTo(0,rcLeft.bottom+1);
	lpDC->LineTo(rcLeft.Width(),rcLeft.bottom+1);
//	memDC.MoveTo(0,0);
//	memDC.LineTo(rcLeft.Width(),0);
//	memDC.MoveTo(0,rcRight.bottom);
//	memDC.LineTo(rcRight.Width(),rcRight.bottom);


	lpDC->SelectObject(&dbpen);

	// Draw Left
	lpDC->MoveTo(rcLeft.left,rcLeft.top+ (rcLeft.Height()/2));
	lindex = m_lCurFilePosition*2;
	for(i=0;i<rcBounds.Width();i++)
	{
		if( lindex+1 < m_lTotalLPoints)
		{
			if(m_lPoints[lindex].x == m_lPoints[lindex+1].x)
			{
				lpDC->LineTo(i,m_lPoints[lindex].y);
				lindex++;
				lpDC->LineTo(i,m_lPoints[lindex].y);				
				lindex++;
			}
			else
			{
				lpDC->LineTo(i,m_lPoints[lindex].y);
				lindex++;
			}
			
		}
		else
			break;
	}
	// Draw Right
	lindex = m_lCurFilePosition*2;
	lpDC->MoveTo(rcRight.left,rcRight.top+ (rcRight.Height()/2));
	for(i=0;i<rcBounds.Width();i++)
	{
		if( lindex+1 < m_lTotalLPoints)
		{
			if(m_rPoints[lindex].x == m_rPoints[lindex+1].x)
			{
				lpDC->LineTo(i,m_rPoints[lindex].y);
				lindex++;
				lpDC->LineTo(i,m_rPoints[lindex].y);				
				lindex++;
			}
			else
			{
				lpDC->LineTo(i,m_rPoints[lindex].y);
				lindex++;
			}
			
		}
		else
			break;
	}

	lpDC->SelectObject(lpOldPen);
}
void CEditWaveFile::Create16BWaveFormBmp(CDC* lpDC,CRect rcBounds)
{

}
void CEditWaveFile::Create8BSWaveFormBmp(CDC* lpDC,CRect rcBounds)
{
}
void CEditWaveFile::Create8BWaveFormBmp(CDC* lpDC,CRect rcBounds)
{
}

void CEditWaveFile::ZoomInToNextLevel()
{
	if(m_lCurrentZoomFactor == 1)
		return;


	m_lCurrentZoomFactor /= 2.0;

}
void CEditWaveFile::ZoomOutToNextLevel()
{
	if(m_lCurrentZoomFactor >= m_lMaxZoom)
		return;

	m_lCurrentZoomFactor *= 2.0;
}
void CEditWaveFile::Draw16BSdbLine(CDC* lpDC,CRect rcBounds,float& scale)
{
	float dby = float(32768/20.0);
	long middle = rcBounds.top+(32768/scale);
	CPen dbpen (PS_SOLID, 0,m_lpOwnerCtrl->clr_DB);

	CPen* lpOldPen = lpDC->SelectObject(&dbpen);

	// Left +6	

	lpDC->MoveTo(rcBounds.left,middle-((dby*6)/scale));
	lpDC->LineTo(rcBounds.right,middle-((dby*6)/scale));
	// Left -6	
	lpDC->MoveTo(rcBounds.left,middle+((dby*6)/scale));
	lpDC->LineTo(rcBounds.right,middle+((dby*6)/scale));

	lpDC->SelectObject(lpOldPen);
}
void CEditWaveFile::GetScrollRanges(long& lLow,long&lHigh,CRect& rcBounds)
{
	if(m_lCurrentZoomFactor >= 128)
	{
		long TotalPoints = long(m_lTotalFileLength/4.0);

		TotalPoints /= (m_lCurrentZoomFactor);

		lLow = 0;
		lHigh = TotalPoints - rcBounds.Width();

		if(lHigh < 0)
			lHigh = 0;
	}
	else
	{
		long TotalPoints = long(m_lTotalFileLength/4.0);

		TotalPoints /= (m_lCurrentZoomFactor);

		lLow = 0;
		lHigh = TotalPoints - rcBounds.Width();

		if(lHigh < 0)
			lHigh = 0;
	}
	
}
void CEditWaveFile::Draw16BSWaveformDirectlyFromFile(CDC* lpDC,CRect rcBounds)
{
	CFile			wvFile;
	long			lCount =1;
	CRect			rcBmp;
	WORD			wBuffer[32000];// File Buffer
	float			scale;
	float			x = 0;
	CPoint			lPoint;	
	CPoint			rPoint;	
	long			lNumOfPoints = 0;
	WORD*			plSample;
	WORD*			prSample;
	BYTE*			lpbSamples = (BYTE*)wBuffer;
	BYTE*			lpbEnd;
	long			lCounter = 0;
	long			lIntervalCounter = 0;

	CPoint			lptLowest;// = ptTemps[0];
	CPoint			lptHighest;// = ptTemps[0];
	CPoint			rptLowest;// = ptTemps[0];
	CPoint			rptHighest;// = ptTemps[0];

	CPoint			ptLastLeft;
	CPoint			ptLastRight;
	CString			sPeakFile;
	CRect rcLeft;
	CRect rcRight;

	rcLeft = rcBounds;
	rcRight = rcBounds;
	CRect rcScale= rcBounds;

	rcScale.top = 0;
	rcScale.bottom = m_lpOwnerCtrl->m_lScaleHeight;
	rcScale.right = rcBounds.Width();
	rcScale.left = 0;

	rcLeft = rcBounds;
	rcRight = rcBounds;

	rcLeft.top = rcScale.bottom;
	rcLeft.bottom = rcLeft.top + (rcLeft.Height()/2)-1;
	rcRight.top = rcLeft.bottom+2;
	rcLeft.left = 0;
	rcRight.left = 0;
	rcLeft.right = rcBounds.Width();
	rcRight.right = rcBounds.Width();
	rcRight.bottom = rcRight.top+rcLeft.Height();


	rcBmp.left = 0;
	rcBmp.right = rcBounds.Width();
	rcBmp.top = 0;
	rcBmp.bottom = rcBounds.Height();

	lpDC->FillSolidRect(&rcBmp,m_lpOwnerCtrl->GetBackColor());

	scale = 65535 / float(rcLeft.Height());

	// Now draw the file...
	
	//pkFile.Seek(m_lCurFilePosition*2,CFile::begin);

	m_lPoints.clear();
	m_rPoints.clear();
	m_lTotalLPoints = 0;

	ptLastLeft.x = rcLeft.left;
	ptLastLeft.y = rcLeft.top+ (rcLeft.Height()/2);
	ptLastRight.x = rcRight.left;
	ptLastRight.y = rcRight.top+ (rcRight.Height()/2);

	Draw16BSdbLine(lpDC,rcLeft,scale);
	Draw16BSdbLine(lpDC,rcRight,scale);
	Draw16BScale(lpDC,rcScale,scale);

	CPen dbpen (PS_SOLID, 0,m_lpOwnerCtrl->clr_Waveform);
	CPen divpen (PS_SOLID, 0,m_lpOwnerCtrl->clr_Divider);

	CPen* lpOldPen = lpDC->SelectObject(&divpen);
	lpDC->MoveTo(0,rcLeft.bottom+1);
	lpDC->LineTo(rcLeft.Width(),rcLeft.bottom+1);
//	memDC.MoveTo(0,0);
//	memDC.LineTo(rcLeft.Width(),0);
//	memDC.MoveTo(0,rcRight.bottom);
//	memDC.LineTo(rcRight.Width(),rcRight.bottom);


	lpDC->SelectObject(&dbpen);

	wvFile.Open((LPCTSTR)m_sWaveFileName,CFile::modeRead|CFile::typeBinary);
	wvFile.Seek(40+((m_lCurFilePosition*m_lCurrentZoomFactor)*4),CFile::begin);

	while(lCount >0 && x<rcBounds.Width())
	{
		lCount = wvFile.Read((void*)wBuffer,64000);

		if(lCount > 0)
		{

			lpbEnd = lpbSamples;
			lpbEnd += lCount;
			// set our pointers to the beginning of the buffer
			plSample = &wBuffer[0];
			prSample = &wBuffer[1];

			while((void*)plSample < (void*)lpbEnd)
			{
				*plSample +=32767;
				*prSample +=32767;


				lPoint.y = ( (int)*plSample / scale );
				lPoint.y += rcLeft.top;
				lPoint.x = int(x);//+rcBounds.left;

				rPoint.y = ( (int)*prSample / scale );
				rPoint.y += rcRight.top;
				rPoint.x = int(x);//+rcBounds.left;


				if(lIntervalCounter > 0)
				{
					if(lPoint.y < lptHighest.y)
						lptHighest = lPoint;
					if(lPoint.y > lptLowest.y)
						lptLowest = lPoint;

					if(rPoint.y < rptHighest.y)
						rptHighest = rPoint;
					if(rPoint.y > rptLowest.y)
						rptLowest = rPoint;
				}
				else 
				{
					lptLowest = lPoint;
					lptHighest = lPoint;
					rptLowest = rPoint;
					rptHighest = rPoint;
				}

				lIntervalCounter++;

				if(lIntervalCounter == m_lCurrentZoomFactor && m_lCurrentZoomFactor<128 )
				{
//					m_lPoints.push_back(lptLowest);
//					m_lPoints.push_back(lptHighest);
//					m_rPoints.push_back(rptLowest);
//					m_rPoints.push_back(rptHighest);
					lpDC->MoveTo(ptLastLeft);
					lpDC->LineTo(lptLowest);
					lpDC->LineTo(lptHighest);
					lpDC->MoveTo(ptLastRight);
					lpDC->LineTo(rptLowest);
					lpDC->LineTo(rptHighest);

					ptLastLeft=lptHighest;
					ptLastRight=rptHighest;


					x+=1;

					if(x > rcBounds.Width())
						break;

					lIntervalCounter=0;
				}

				plSample +=2;
				prSample +=2;
			}
		}
	}
	wvFile.Close();

	lpDC->SelectObject(lpOldPen);
}
void CEditWaveFile::Draw16BScale(CDC* lpDC,CRect rcBounds,float& scale)
{
//	float fScaler = 0.0030517578125;

	CRect rcScale;

	float fTickInterval = unsigned long(m_WaveHeader.nSamplesPerSec)/float(m_lCurrentZoomFactor);

	long Total = m_lCurFilePosition*m_lCurrentZoomFactor;
//	float remMaj = m_lCurFilePosition/2;
//	float remMin;

	long lMajTickCount = m_lCurFilePosition;
	long lMinTickCount = long(m_lCurFilePosition)%m_lpOwnerCtrl->m_lMinTickInterval;


	long i;
	long x = 0;

	CPen dbpen (PS_SOLID, 0,m_lpOwnerCtrl->clr_ScaleTicks);

	CPen* lpOldPen = lpDC->SelectObject(&dbpen);
//	COLORREF			clr_ScalerBack;
//	COLORREF			clr_ScalerPen;
	lpDC->FillSolidRect(&rcBounds,m_lpOwnerCtrl->clr_ScaleBackround);


	CFont* lpOldFont = m_lpOwnerCtrl->SelectStockFont(lpDC);

	for(i=0;i<rcBounds.Width();i++)
	{
		
		if(lMajTickCount%m_lpOwnerCtrl->m_lMajTickInterval == 0)
		{
			CString sTime;
			CRect rcText;

			rcText.left = i;
			rcText.top = rcBounds.top;
			rcText.right = rcText.left+100;
			rcText.bottom = rcBounds.bottom-m_lpOwnerCtrl->m_lMajTickSize;

			long lRealPosition = (lMajTickCount*m_lCurrentZoomFactor);

			float fTime = (lRealPosition/44100.0)/60.0;
			sTime.Format("%2.4f",fTime);
			lpDC->MoveTo(i,rcBounds.bottom);
			lpDC->LineTo(i,rcBounds.top);
			lpDC->MoveTo(i,rcBounds.top);
			lpDC->SetTextColor(m_lpOwnerCtrl->clr_ScaleNumbers);
			if(lRealPosition < m_lTotalFileLength)
				lpDC->DrawText(sTime,&rcText,DT_LEFT);
		//	lMajTickCount=0;
		}

		if(lMinTickCount == m_lpOwnerCtrl->m_lMinTickInterval)
		{
			lpDC->MoveTo(i,rcBounds.bottom);
			lpDC->LineTo(i,rcBounds.bottom-m_lpOwnerCtrl->m_lMinTickSize);
			lMinTickCount=0;
		}

		
		lMajTickCount++;
		lMinTickCount++;

	}
	lpDC->MoveTo(0,rcBounds.bottom);
	lpDC->LineTo(rcBounds.right,rcBounds.bottom);
	lpDC->SelectObject(lpOldPen);
	lpDC->SelectObject(lpOldFont);
}
float CEditWaveFile::GetFileLengthInSeconds()
{
	return ( (m_lTotalFileLength/4.0)/44100.0);
}
void CEditWaveFile::DrawUnInitialized(CDC* lpDC,CRect rcBounds)
{
	CRect			rcBmp;
	float			scale;

	CRect rcLeft;
	CRect rcRight;
	CRect rcScale= rcBounds;

	rcScale.top = 0;
	rcScale.bottom = 30;
	rcScale.right = rcBounds.Width();
	rcScale.left = 0;

	rcLeft = rcBounds;
	rcRight = rcBounds;

	rcLeft.top = rcScale.bottom;
	rcLeft.bottom = rcLeft.top + (rcLeft.Height()/2)-1;
	rcRight.top = rcLeft.bottom+2;
	rcLeft.left = 0;
	rcRight.left = 0;
	rcLeft.right = rcBounds.Width();
	rcRight.right = rcBounds.Width();
	rcRight.bottom = rcRight.top+rcLeft.Height();


	rcBmp.left = 0;
	rcBmp.right = rcBounds.Width();
	rcBmp.top = 0;
	rcBmp.bottom = rcBounds.Height();

	lpDC->FillSolidRect(&rcBmp,m_lpOwnerCtrl->GetBackColor());

	scale = 65535 / float(rcLeft.Height());

}
void CEditWaveFile::SetCursorPosition(long lPosition)
{
	m_lCursorPosition = (lPosition+m_lCurFilePosition)*m_lCurrentZoomFactor;

	if(m_lCursorPosition > (m_lTotalFileLength/4.0) )
		m_lCursorPosition = long(m_lTotalFileLength/4.0);
	else if(m_lCursorPosition < 0)
		m_lCursorPosition = 0;
}
void CEditWaveFile::SetSelectionPosition(long lPosition)
{
	m_lStartOfSelection = (lPosition+m_lCurFilePosition)*m_lCurrentZoomFactor;

	if(m_lStartOfSelection > (m_lTotalFileLength/4.0) )
		m_lStartOfSelection = long(m_lTotalFileLength/4.0);
	else if(m_lStartOfSelection < 0)
		m_lStartOfSelection = 0;

}
void CEditWaveFile::SetCursorAsStartSelec()
{
	m_lStartOfSelection = m_lCursorPosition;
}
BOOL CEditWaveFile::IsPointVisible(CRect& rcBounds,long lFilePosition)
{
	if(lFilePosition < 0)
		return FALSE;

	long lend = (rcBounds.Width()-1)+m_lCurFilePosition;
	long lStart = m_lCurFilePosition;
	long lCursor = long(lFilePosition/m_lCurrentZoomFactor);

	if(lCursor < lend && lCursor > lStart)
	{
		rcBounds.left = int(lCursor - lStart);
		return TRUE;
	}

	return FALSE;

}
BOOL CEditWaveFile::IsCursorVisible(CRect& rcBounds)
{
	if(m_lCursorPosition < 0)
		return FALSE;

	long lend = (rcBounds.Width()-1)+m_lCurFilePosition;
	long lStart = m_lCurFilePosition;
	long lCursor = long(m_lCursorPosition/m_lCurrentZoomFactor);

	if(lCursor < lend && lCursor > lStart)
	{
		rcBounds.left = int(lCursor - lStart);
		return TRUE;
	}

	return FALSE;

}
CRect CEditWaveFile::SizingSelection(long lPosition,CRect rcBounds)
{
	CRect rcReturn;

	SetRect(&rcReturn,-1,-1,-1,-1);

	if(m_lStartOfSelection == -1)
		return rcReturn;

	long lend = (rcBounds.Width()-1)+m_lCurFilePosition;
	long lStart = m_lCurFilePosition;
	long lCursor = long(m_lCursorPosition/m_lCurrentZoomFactor);
	long lStartSelection = long(m_lStartOfSelection/m_lCurrentZoomFactor);

	if(m_bDraggingCursorInSel == FALSE)
	{
		SetSelectionPosition(lPosition);
	}
	else if(m_bDraggingCursorInSel == TRUE)
	{
		SetCursorPosition(lPosition);
	}


	lCursor = long(m_lCursorPosition/m_lCurrentZoomFactor);
	lStartSelection = long(m_lStartOfSelection/m_lCurrentZoomFactor);


	if(lCursor > lStartSelection)
	{
		if( (lCursor - lStart) < 0)
			return rcReturn;

		rcReturn = rcBounds;
		rcReturn.left = int(lStartSelection - lStart);
		rcReturn.right = int(lCursor - lStart);
	}
	else if(lCursor < lStartSelection)
	{
		if( (lStartSelection - lStart) < 0)
			return rcReturn;

		rcReturn = rcBounds;
		rcReturn.left = int(lCursor - lStart);
		rcReturn.right = int(lStartSelection - lStart);
	}

	// Now Clip it against the Window
	if(rcReturn.right > rcBounds.right)
		rcReturn.right = rcBounds.right;

	return rcReturn;
}
CRect CEditWaveFile::GetSelectionRect(CRect& rcBounds)
{
	CRect rcReturn;

	SetRect(&rcReturn,-1,-1,-1,-1);

	if(m_lCursorPosition == m_lStartOfSelection || m_lStartOfSelection == -1)
		return rcReturn;

	long lend = (rcBounds.Width()-1)+m_lCurFilePosition;
	long lStart = m_lCurFilePosition;
	long lCursor = long(m_lCursorPosition/m_lCurrentZoomFactor);
	long lStartSelection = long(m_lStartOfSelection/m_lCurrentZoomFactor);

	if(lCursor > lStartSelection)
	{
		if( (lCursor - lStart) < 0)
			return rcReturn;

		rcReturn = rcBounds;
		rcReturn.left = int(lStartSelection - lStart);
		rcReturn.right = int(lCursor - lStart);
	}
	else if(lCursor < lStartSelection)
	{
		if( (lStartSelection - lStart) < 0)
			return rcReturn;

		rcReturn = rcBounds;
		rcReturn.left = int(lCursor - lStart);
		rcReturn.right = int(lStartSelection - lStart);
	}

	// Now Clip it against the Window
	if(rcReturn.right > rcBounds.right)
		rcReturn.right = rcBounds.right;

	return rcReturn;

}
void CEditWaveFile::GetSelectionRanges(long& lLow,long& lHigh)
{
	// we do *2 because right now we are reading 16 bit stereo

	if(m_lCursorPosition > m_lStartOfSelection)
	{
		lLow = m_lStartOfSelection*2;
		lHigh = m_lCursorPosition*2;
	}
	else
	{
		lLow = m_lCursorPosition*2;
		lHigh = m_lStartOfSelection*2;
	}
}
void CEditWaveFile::BeginingDragOfSelection(long lPosition,CRect rcBounds,BOOL bLeft)
{
	// we now figure out what is going to be dragged
	long lend = (rcBounds.Width()-1)+m_lCurFilePosition;
	long lStart = m_lCurFilePosition;
	long lCursor = long(m_lCursorPosition/m_lCurrentZoomFactor);
	long lStartSelection = long(m_lStartOfSelection/m_lCurrentZoomFactor);

	if(lCursor > lStartSelection && bLeft == TRUE)
	{
		m_bDraggingCursorInSel = FALSE;
	}
	else if(lCursor > lStartSelection && bLeft == FALSE)
	{
		m_bDraggingCursorInSel = TRUE;
	}
	else if(lCursor < lStartSelection && bLeft == TRUE)
	{
		m_bDraggingCursorInSel = TRUE;
	}
	else if(lCursor < lStartSelection && bLeft == FALSE)
	{
		m_bDraggingCursorInSel = FALSE;
	}


}
