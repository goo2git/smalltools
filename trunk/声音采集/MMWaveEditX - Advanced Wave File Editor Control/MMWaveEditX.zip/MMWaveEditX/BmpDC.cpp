// BmpDC.cpp: implementation of the CBmpDC class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "BmpDC.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBmpDC::CBmpDC()
{

}
CBmpDC::CBmpDC(CDC* lpDC,CRect rcBounds,BOOL bCopyBkg)
{
	CreateCompatibleDC(lpDC);

	m_bmpTemp.CreateDiscardableBitmap(lpDC,rcBounds.Width(),rcBounds.Height());

	m_lpOldBmp = SelectObject(&m_bmpTemp);

	if(bCopyBkg == TRUE)
	{
		BitBlt(0,0,rcBounds.Width(),rcBounds.Height(),lpDC,0,0,SRCCOPY);
	}

}
CBmpDC::~CBmpDC()
{
	SelectObject(m_lpOldBmp);
}
