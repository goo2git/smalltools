//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_SCOPE                       101
#define IDC_RECORD                      1000
#define IDC_STOP                        1001
#define IDC_DEVICE_LIST                 1002
#define IDC_METER_LEFT                  1004
#define IDC_METER_RIGHT                 1005
#define IDC_REFESHSLIDER                1007
#define IDC_PROG_GRAPH_LEFT1            2001
#define IDC_PROG_GRAPH_LEFT2            2002
#define IDC_PROG_GRAPH_LEFT3            2003
#define IDC_PROG_GRAPH_LEFT4            2004
#define IDC_PROG_GRAPH_LEFT5            2005
#define IDC_PROG_GRAPH_LEFT6            2006
#define IDC_PROG_GRAPH_LEFT7            2007
#define IDC_PROG_GRAPH_LEFT8            2008
#define IDC_PROG_GRAPH_LEFT9            2009
#define IDC_PROG_GRAPH_LEFT10           2010
#define IDC_PROG_GRAPH_RIGHT1           3001
#define IDC_PROG_GRAPH_RIGHT2           3002
#define IDC_PROG_GRAPH_RIGHT3           3003
#define IDC_PROG_GRAPH_RIGHT4           3004
#define IDC_PROG_GRAPH_RIGHT5           3005
#define IDC_PROG_GRAPH_RIGHT6           3006
#define IDC_PROG_GRAPH_RIGHT7           3007
#define IDC_PROG_GRAPH_RIGHT8           3008
#define IDC_PROG_GRAPH_RIGHT9           3009
#define IDC_PROG_GRAPH_RIGHT10          3010
#define IDC_PROG_GRAPH_BOTH1            4001
#define IDC_PROG_GRAPH_BOTH2            4002
#define IDC_PROG_GRAPH_BOTH3            4003
#define IDC_PROG_GRAPH_BOTH4            4004
#define IDC_PROG_GRAPH_BOTH5            4005
#define IDC_PROG_GRAPH_BOTH6            4006
#define IDC_PROG_GRAPH_BOTH7            4007
#define IDC_PROG_GRAPH_BOTH8            4008
#define IDC_PROG_GRAPH_BOTH9            4009
#define IDC_PROG_GRAPH_BOTH10           4010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
