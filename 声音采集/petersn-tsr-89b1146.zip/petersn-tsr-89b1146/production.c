 // Production model for producing hypotheses
#include <stdlib.h>

#include "production.h"

void sort_candidates() {

    

}

