/*--------------------------------------------------------------*/
// Copyright (C) 2010 �人��ʯ�Ƽ����޹�˾
// �ļ�����EkVolumeDectector.cs
// �ļ�����������
// ʵʱ��׽��������
// �޸ı�ʶ��zhang 20100527
// �޸�������ɾ���˲��ֲ���Ҫ�Ĺ��ܣ��޸��˳�ʼֵ��Ϊ0��bug
// ��ע��ԭ����Jacob Klint
/*---------------------------------------------------------------*/

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.DirectX.DirectSound;
using System.Threading;
using System.Collections.Specialized;

namespace RockSoft.Ecourse
{
    public class EkVolumeDectector : System.Windows.Forms.UserControl
    {
        private const int SAMPLES = 8;
        private static int[] SAMPLE_FORMAT_ARRAY = { SAMPLES, 2, 1 };
        private static CaptureDevicesCollection audioDevices;
        private static StringCollection deviceNames;

        private string deviceName = "û�м�⵽��Ƶ�����豸";
        private int deviceIndex = -1;
        private Microsoft.DirectX.DirectSound.CaptureBuffer buffer;
        private System.Threading.Thread liveVolumeThread;
        private int sampleDelay = 100;
        private int frameDelay = 10;
        private User.Windows.Forms.ProgressBarGradient progressBar;

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        static EkVolumeDectector()
        {
            //��ȡϵͳ�豸
            audioDevices = new CaptureDevicesCollection();
            //�豸����
            deviceNames = new StringCollection();

            for (int i = 0; i < audioDevices.Count; i++)
            {
                deviceNames.Add(audioDevices[i].Description);
            }
        }


        public EkVolumeDectector()
        {
            InitializeComponent();
            progressBar.MaximumValue = Int16.MaxValue + 1;
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                    components.Dispose();
            }

            Stop();

            base.Dispose(disposing);
        }

        #region Component Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.progressBar = new User.Windows.Forms.ProgressBarGradient();
            this.SuspendLayout();
            // 
            // progressBar
            // 
            this.progressBar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.progressBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.progressBar.Location = new System.Drawing.Point(0, 0);
            this.progressBar.MaximumColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.progressBar.MaximumValue = 128;
            this.progressBar.MidColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.progressBar.MidColorPosition = 0.75F;
            this.progressBar.MinimumColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.progressBar.MinimumValue = 0;
            this.progressBar.MouseInteractive = false;
            this.progressBar.Name = "progressBar";
            this.progressBar.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.progressBar.ShowMidColor = true;
            this.progressBar.Size = new System.Drawing.Size(150, 20);
            this.progressBar.TabIndex = 0;
            this.progressBar.Value = 128;
            // 
            // EkVolumeDectector
            // 
            this.Controls.Add(this.progressBar);
            this.Name = "EkVolumeDectector";
            this.Size = new System.Drawing.Size(150, 20);
            this.ResumeLayout(false);

        }
        #endregion

        protected override void OnResize(EventArgs e)
        {
            if (progressBar.Orientation == Orientation.Horizontal)
            {
                SuspendLayout();
                progressBar.Dock = DockStyle.Top;
                //progressBar.Height = ClientRectangle.Height / 2 - 8 - 2;


                //progressBar.Width = ClientRectangle.Width - 16;
                ResumeLayout(true);
            }
            else
            {
                SuspendLayout();
                progressBar.Dock = DockStyle.Left;
                //progressBar.Width = ClientRectangle.Width / 2 - 8 - 2;

                //progressBar.Height = ClientRectangle.Height;
                ResumeLayout(true);
            }
        }

        public IList DeviceNames
        {
            get
            {
                return deviceNames;
            }
        }

        public int SelectedDeviceIndex
        {
            get
            {
                return deviceNames.IndexOf(deviceName);
            }

            set
            {
                if (deviceIndex != value)
                {
                    Stop();

                    if ((value >= 0) && (value < deviceNames.Count))
                    {

                        deviceIndex = value;
                        deviceName = deviceNames[deviceIndex];
                        Start();
                    }
                    else
                    {
                        deviceIndex = -1;
                        deviceName = "û�м�⵽��Ƶ�����豸";
                        MessageBox.Show(deviceName);
                    }
                }
            }
        }

        public bool VisualizerOn
        {
            get
            {
                return (liveVolumeThread != null);
            }

            set
            {
                if (VisualizerOn != value)
                {
                    if (value)
                    {
                        Start();
                    }
                    else
                    {
                        Stop();
                    }
                }
            }
        }

        public void Start()
        {
            Stop();

            if (deviceIndex != -1)
            {
                // ���� capture ����
                Capture cap = new Capture(audioDevices[deviceIndex].DriverGuid);
                // ������ capture buffer���������
                CaptureBufferDescription desc = new CaptureBufferDescription();
                WaveFormat wf = new WaveFormat();
                wf.BitsPerSample = 16;
                wf.SamplesPerSecond = 44100;
                wf.Channels = 2;
                // ���ݵ���С��ԭ�ӵ�Ԫ
                wf.BlockAlign = (short)(wf.Channels * wf.BitsPerSample / 8);
                wf.AverageBytesPerSecond = wf.BlockAlign * wf.SamplesPerSecond;
                // δ��ѹ����PCM
                wf.FormatTag = WaveFormatTag.Pcm;

                desc.Format = wf;
                desc.BufferBytes = SAMPLES * wf.BlockAlign;
                // ���� capturebuffer����
                buffer = new Microsoft.DirectX.DirectSound.CaptureBuffer(desc, cap);
                // ��׽����������
                buffer.Start(true);

                liveVolumeThread = new Thread(new ThreadStart(updateProgress));
                liveVolumeThread.Priority = ThreadPriority.Lowest;
                liveVolumeThread.Start();
            }
        }

        public void Stop()
        {
            if (liveVolumeThread != null)
            {
                liveVolumeThread.Abort();
                liveVolumeThread.Join();
                liveVolumeThread = null;
            }

            if (buffer != null)
            {
                if (buffer.Capturing)
                {
                    buffer.Stop();
                }

                buffer.Dispose();
                buffer = null;
            }
        }

        public int SampleDelay
        {
            get
            {
                return sampleDelay;
            }

            set
            {
                sampleDelay = Math.Max(0, value);

                if (frameDelay > sampleDelay)
                {
                    frameDelay = sampleDelay;
                }
            }
        }

        public int FrameDelay
        {
            get
            {
                return frameDelay;
            }

            set
            {
                frameDelay = Math.Max(0, Math.Min(sampleDelay, value));
            }
        }

        public string SelectedDeviceName
        {
            get
            {
                return deviceName;
            }

            set
            {
                SelectedDeviceIndex = deviceNames.IndexOf(value);
            }
        }

        public Orientation Orientation
        {
            get
            {
                return progressBar.Orientation;
            }

            set
            {
                SuspendLayout();
                progressBar.Orientation = value;
                ResumeLayout();

                OnResize(null);
            }
        }

        private void updateProgress()
        {
            while (true)
            {
                int tempFrameDelay = frameDelay;
                int tempSampleDelay = sampleDelay;
                Array samples = buffer.Read(0, typeof(Int16), LockFlag.FromWriteCursor, SAMPLE_FORMAT_ARRAY);

                // determine the step size necessary for each iteration
                int goal = 0;

                // average across all samples to get the goals
                for (int i = 0; i < SAMPLES; i++)
                {
                    goal += (Int16)samples.GetValue(i, 0, 0);
                }

                goal = (int)Math.Abs(goal / SAMPLES);

                double range = goal - progressBar.Value;

                double exactValue = progressBar.Value;

                double stepSize = range / tempSampleDelay * tempFrameDelay;
                if (Math.Abs(stepSize) < .01)
                {
                    stepSize = Math.Sign(range) * .01;
                }
                double absStepSize = Math.Abs(stepSize);

                // increment/decrement the bars' values until both equal their desired goals,
                // sleeping between iterations
                if ((progressBar.Value == goal))
                {
                    Thread.Sleep(tempSampleDelay);
                }
                else
                {
                    do
                    {
                        if (progressBar.Value != goal)
                        {
                            if (absStepSize < Math.Abs(goal - progressBar.Value))
                            {
                                exactValue += stepSize;
                                progressBar.Value = (int)Math.Round(exactValue);
                            }
                            else
                            {
                                progressBar.Value = goal;
                            }
                        }

                        Thread.Sleep(tempFrameDelay);
                    } while ((progressBar.Value != goal)); 
                }
            }
        }
    }
    
}
