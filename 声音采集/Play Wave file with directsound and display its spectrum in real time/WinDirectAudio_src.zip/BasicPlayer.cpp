#include "BasicPlayer.h"

/************************************************************************/
/* CSystem                                                              */
/************************************************************************/
inline void set_low(jlong* value, jint low)
{
	*value &= (jlong)0xffffffff << 32;
	*value |= (jlong)(julong)(juint)low;
}

inline void set_high(jlong* value, jint high)
{
	*value &= (jlong)(julong)(juint)0xffffffff;
	*value |= (jlong)high       << 32;
}

jlong as_long(LARGE_INTEGER x) {
	jlong result = 0; // initialization to avoid warning
	set_high(&result, x.HighPart);
	set_low(&result,  x.LowPart);
	return result;
}

LARGE_INTEGER liFrequency = {0};
BOOL gSupportPerformanceFrequency = QueryPerformanceFrequency(&liFrequency);
__int64 CSystem::frequency = as_long(liFrequency);
int CSystem::ready = 1;

/************************************************************************/
/* CPlayThread                                                          */
/************************************************************************/
CPlayThread::CPlayThread(CBasicPlayer* pPlayer) : CThread()
{
	m_Player = pPlayer;
	m_cs = new CCriticalSection;
}

CPlayThread::~CPlayThread(void)
{
	if(m_cs != NULL)
		delete m_cs;

	m_cs = NULL;
}

void CPlayThread::Execute()
{
	if(m_Player == NULL)
		return;

	if(m_Stop == TRUE)
		return;

	const DWORD buffersize = 16000;
	SetFilePointer(m_Player->GetFileHandle(), 44, NULL, FILE_BEGIN);
	INT32 count = DAUDIO_GetDirectAudioDeviceCount();

	// wait time = 1/4 of buffer time
	DWORD waitTime = (DWORD)((m_Player->m_BufferSize*1000.0F)/(m_Player->m_SampleRate*m_Player->m_FrameSize));
	waitTime = (DWORD)(waitTime / 4);
	if(waitTime<10) waitTime = 1;
	if(waitTime>1000) waitTime = 1000;

	m_Player->m_info = (DS_Info*)DAUDIO_Open(0, 0 , TRUE, DAUDIO_PCM, m_Player->m_SampleRate,
		m_Player->m_BitPerSample, m_Player->m_FrameSize, m_Player->m_Channels, TRUE, FALSE,
		m_Player->m_BufferSize);
	m_Player->m_bytePosition = 0;

	if(DAUDIO_Start((void*)m_Player->m_info, TRUE))
	{
		m_Player->m_SpectrumAnalyserThread->Resume();
		printf("start play ...\n");
		char buffer[buffersize];
		while(!m_Stop)
		{
			DWORD dwRead;
			if(ReadFile(m_Player->GetFileHandle(), (void*)buffer, buffersize, &dwRead, NULL) == FALSE)
				break;

			if(dwRead <= 0)
				break;

			DWORD len = dwRead;
			DWORD offset = 0;
			DWORD written = 0;

			/*
			* in this loop, the data may can not be written to device one time,
			* maybe more than one times. so, we need this loop to process it.
			*/
			while(TRUE)
			{
				m_cs->Enter();
				int thisWritten = DAUDIO_Write((void*)m_Player->m_info, buffer+offset, len);
				if(thisWritten < 0) break;
				m_Player->m_bytePosition += thisWritten;
				m_cs->Leave();

				len -= thisWritten;
				written += thisWritten;
				if(len > 0)
				{
					offset += thisWritten;
					m_cs->Enter();
					Sleep(waitTime);
					m_cs->Leave();
				}
				else break;
			}

			//copy audio data to audio buffer
			//for auido data sychronize
			DWORD pLength = dwRead;
			if(m_Player->m_AudioDataBuffer != NULL)
			{
				int wOverrun = 0;
				if (m_Player->m_position + pLength > (int)(m_Player->m_AudioDataBufferLength - 1)) {
					wOverrun = (m_Player->m_position + pLength) - m_Player->m_AudioDataBufferLength;
					pLength = m_Player->m_AudioDataBufferLength - m_Player->m_position;
				}

				memcpy(m_Player->m_AudioDataBuffer + m_Player->m_position, buffer, pLength);
				if (wOverrun > 0) {
					memcpy(m_Player->m_AudioDataBuffer, buffer + pLength, wOverrun);
					m_Player->m_position = wOverrun;
				} else {
					m_Player->m_position += pLength;
				}
			}
		}

		m_Player->m_SpectrumAnalyserThread->Stop();
		DAUDIO_Stop((void*)m_Player->m_info, TRUE);
		DAUDIO_Close((void*)m_Player->m_info, TRUE);
		m_Player->m_bytePosition = 0;

		printf("stop play.\n");
	}

	m_Player->m_info = NULL;
}

/************************************************************************/
/* CSpectrumAnalyserThread                                              */
/************************************************************************/
CSpectrumAnalyserThread::CSpectrumAnalyserThread(CBasicPlayer* pPlayer)
{
	m_Player = pPlayer;
	m_cs = new CCriticalSection;
	m_process = TRUE;
	m_lfp = 0;
	m_frameSize = DEFAULT_FRAME_SIZE;
}

CSpectrumAnalyserThread::~CSpectrumAnalyserThread(void)
{
	if(m_cs != NULL)
		delete m_cs;

	m_cs = NULL;
}

int CSpectrumAnalyserThread::calculateSamplePosition()
{
	long wFp = m_Player->GetLongFramePosition();
	long wNfp = m_lfp;

	m_lfp = wFp;

	int wSdp = (int) ((long) (wNfp * m_frameSize) - (long) (m_Player->m_AudioDataBufferLength * m_Player->m_offset));
	return wSdp;
}

void CSpectrumAnalyserThread::processSamples(int nPosition)
{
	int c = nPosition;
	if (m_Player->m_channelMode == 1 && m_Player->m_sampleType == 1) {
		for (int a = 0; a < m_Player->m_SampleSize;) {
			if ((DWORD)c >= m_Player->m_AudioDataBufferLength) {
				m_Player->m_offset++;
				c -= m_Player->m_AudioDataBufferLength;
			}

			m_Player->m_Left[a] = (float) m_Player->m_AudioDataBuffer[c] / 128;
			m_Player->m_Right[a] = m_Player->m_Left[a];
			a++;
			c++;
		}

	} else if (m_Player->m_channelMode == 2 && m_Player->m_sampleType == 1) {
		for (int a = 0; a < m_Player->m_SampleSize;) {
			if ((DWORD)c >= m_Player->m_AudioDataBufferLength) {
				m_Player->m_offset++;
				c -= m_Player->m_AudioDataBufferLength;
			}

			m_Player->m_Left[a] = (float) m_Player->m_AudioDataBuffer[c] / 128;
			m_Player->m_Right[a] = (float) m_Player->m_AudioDataBuffer[c + 1] / 128;
			a++;
			c += 2;
		}

	} else if (m_Player->m_channelMode == 1 && m_Player->m_sampleType == 2) {
		for (int a = 0; a < m_Player->m_SampleSize;) {
			if ((DWORD)c >= m_Player->m_AudioDataBufferLength) {
				m_Player->m_offset++;
				c -= m_Player->m_AudioDataBufferLength;
			}

			m_Player->m_Left[a] = (float) ((m_Player->m_AudioDataBuffer[c + 1] << 8) +
				m_Player->m_AudioDataBuffer[c]) / 32767;
			m_Player->m_Right[a] = m_Player->m_Left[a];
			a++;
			c += 2;
		}

	} else if (m_Player->m_channelMode == 2 && m_Player->m_sampleType == 2) {
		for (int a = 0; a < m_Player->m_SampleSize;) {
			if ((DWORD)c >= m_Player->m_AudioDataBufferLength) {
				m_Player->m_offset++;
				c -= m_Player->m_AudioDataBufferLength;
			}

			m_Player->m_Left[a] = (float) ((m_Player->m_AudioDataBuffer[c + 1] << 8) +
				m_Player->m_AudioDataBuffer[c]) / 32767;
			m_Player->m_Right[a] = (float) ((m_Player->m_AudioDataBuffer[c + 3] << 8) +
				m_Player->m_AudioDataBuffer[c + 2]) / 32767;
			a++;
			c += 4;
		}

	}
}


void CSpectrumAnalyserThread::Execute()
{
	while(!m_Stop)
	{
		__int64 wStn = CSystem::nanoTime();
		int wSdp = calculateSamplePosition();

		
		//StringCbPrintf(BUFFER, 256, _TEXT("wSdp=%d\n"), wSdp);
		//OutputDebugString(BUFFER);

		if (wSdp > 0)
			processSamples(wSdp);

		for (int a = 0; a < 1; a++)
		{
			float wFrr = (float) m_Player->m_FpsAsNS / (float) m_Player->m_DesiredFpsAsNS;
			m_Player->Process(wFrr);
		}

		long wDelay = m_Player->m_FpsAsNS - (long)(CSystem::nanoTime() - wStn);
		if (wDelay > 0L)
		{
			DWORD ms = (DWORD)wDelay / 0xf4240L;
			DWORD ns = (DWORD)wDelay % 0xf4240L;
			if(ns >= 500000) ms++;

			/*
			 * i test more and more times, i found when ms more than 33 ms,
			 * the spectrum will stop in a short time. i do not know why?!!
			 */
			if(ms > 33)
			{
				TCHAR BUFFER[256];
				StringCbPrintf(BUFFER, 256, _TEXT("unkown reason, sleep %d ms.\n"), ms);
				OutputDebugString(BUFFER);
			}
			
			Sleep(ms);

			if (m_Player->m_FpsAsNS > m_Player->m_DesiredFpsAsNS)
				m_Player->m_FpsAsNS -= wDelay;
			else
				m_Player->m_FpsAsNS = m_Player->m_DesiredFpsAsNS;
		}
		else
		{
			m_Player->m_FpsAsNS += -wDelay;
			Sleep(10);
		}
	}

}

/************************************************************************/
/* CBasicPlayer                                                         */
/************************************************************************/
CBasicPlayer::CBasicPlayer(HWND hWnd, TCHAR *pszFileName) : m_PlayThread(NULL),
			m_hWnd(hWnd), m_hFile(INVALID_HANDLE_VALUE), m_Playing(FALSE)
{
	if(pszFileName == NULL)
	{
		MessageBox(hWnd, _TEXT("You should specify a file to play."), _TEXT("Error"), MB_OK);
		return;
	}

	size_t len;
	StringCbLength(pszFileName, STRSAFE_MAX_LENGTH, &len);
	if(len == 0)
	{
		MessageBox(hWnd, _TEXT("You should specify a file to play."), _TEXT("Error"), MB_OK);
		return;
	}

	m_hFile = CreateFile(pszFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(m_hFile == INVALID_HANDLE_VALUE)
	{
		TCHAR buf[2*MAX_PATH];
		StringCbPrintf(buf, 2*MAX_PATH, _TEXT("Can not open file '%s'  to play."), pszFileName);
		MessageBox(hWnd, buf, _TEXT("Error"), MB_OK);
		return;
	}

	StringCchCopy(m_FileName, len, pszFileName);
	m_PlayThread = new CPlayThread(this);
	m_SpectrumAnalyserThread = new CSpectrumAnalyserThread(this);
	m_cs = new CCriticalSection;

	m_BufferSize = DEFAULT_BUFFER_SIZE;
	m_SampleRate = DEFAULT_SAMPLE_RATE;
	m_FrameSize = DEFAULT_FRAME_SIZE;
	m_BitPerSample = DEFAULT_BITS_PER_SAMPLE;
	m_Channels = DEFAULT_CHANNELS;

	/* digital signal process */
	m_AudioDataBufferLength = DEFAULT_BUFFER_SIZE << 1;
	m_AudioDataBuffer = new BYTE[m_AudioDataBufferLength];
	m_SampleSize = DEFAULT_SAMPLE_SIZE;
	m_DesiredFpsAsNS = 0x3B9ACA00L / DEFAULT_FPS;
	m_FpsAsNS = m_DesiredFpsAsNS;
	m_Left = new FLOAT[DEFAULT_SAMPLE_SIZE];
	m_Right = new FLOAT[DEFAULT_SAMPLE_SIZE];
	m_position = 0;
	m_offset = 0;
	m_sampleType = SAMPLE_TYPE_SIXTEEN_BIT;
	m_channelMode = CHANNEL_MODE_STEREO;

	memset(m_AudioDataBuffer, 0, m_AudioDataBufferLength);
	memset(m_Left, 0, DEFAULT_SAMPLE_SIZE);
	memset(m_Right, 0, DEFAULT_SAMPLE_SIZE);

	/* spectrum analyser */
	m_width = DEFAULT_WIDTH;
	m_height = DEFAULT_HEIGHT - 40;
	m_saFFTSampleSize = DEFAULT_SPECTRUM_ANALYSER_FFT_SAMPLE_SIZE;
	m_saBands = DEFAULT_SPECTRUM_ANALYSER_BAND_COUNT;
	m_saDecay = DEFAULT_SPECTRUM_ANALYSER_DECAY;
	m_FFT = new CFastFourierTransform(m_saFFTSampleSize);
	m_peaks = new INT[m_saBands];
	m_peaksDelay = new INT[m_saBands];
	m_oldFFT = new FLOAT[m_saFFTSampleSize];
	m_saMultiplier = (FLOAT)((m_saFFTSampleSize / 2) / m_saBands);
	m_barOffset = 1;
	m_peakDelay = DEFAULT_SPECTRUM_ANALYSER_PEAK_DELAY;
	m_peaksEnabled = TRUE;

	memset(m_peaks, 0, m_saBands);
	memset(m_peaksDelay, 0, m_saBands);
	memset(m_oldFFT, 0, m_saFFTSampleSize);

	/* draw spectrum analyser */
	RECT rect;
	GetClientRect(m_hWnd, &rect);
	m_winwidth = rect.right - rect.left;
	m_winheight = rect.bottom - rect.top;

	m_hdcScreen = GetWindowDC(m_hWnd);
	m_hdcMem = CreateCompatibleDC(m_hdcScreen);
	m_hbmMem = CreateCompatibleBitmap(m_hdcScreen, m_winwidth, m_winheight);
	m_hbrush = CreateSolidBrush(RGB(0, 0, 0));
	m_hbrush1 = CreateSolidBrush(RGB(125, 125, 125));
	m_hOld = (HBITMAP)SelectObject(m_hdcMem, m_hbmMem);
	m_hbrushOld = (HBRUSH)SelectObject(m_hdcMem, m_hbrush);
	m_hbrushOld1 = (HBRUSH)SelectObject(m_hdcMem, m_hbrush1);
}

CBasicPlayer::~CBasicPlayer(void)
{
	if(m_hFile != INVALID_HANDLE_VALUE)
		CloseHandle(m_hFile);

	if(m_PlayThread != NULL)
		delete m_PlayThread;

	if(m_cs != NULL)
		delete m_cs;

	if(m_AudioDataBuffer != NULL)
		delete [] m_AudioDataBuffer;

	if(m_Left != NULL)
		delete [] m_Left;

	if(m_Right != NULL)
		delete [] m_Right;

	if(m_FFT != NULL)
		delete m_FFT;

	if(m_peaks != NULL)
		delete [] m_peaks;

	if(m_peaksDelay != NULL)
		delete [] m_peaksDelay;

	if(m_oldFFT != NULL)
		delete [] m_oldFFT;

	m_hFile = INVALID_HANDLE_VALUE;
	m_PlayThread = NULL;
	m_cs = NULL;
	m_AudioDataBuffer = NULL;
	m_Left = NULL;
	m_Right = NULL;
	m_FFT = NULL;
	m_peaks = NULL;
	m_peaksDelay = NULL;
	m_oldFFT = NULL;

	/* draw spectrum analyser */
	SelectObject(m_hdcMem, m_hOld);
	DeleteObject(m_hbmMem);
	SelectObject(m_hdcMem, m_hbrushOld);
	SelectObject(m_hdcMem, m_hbrushOld1);
	DeleteObject(m_hbrush);
	DeleteObject(m_hbrush1);
	DeleteDC(m_hdcMem);

}

void CBasicPlayer::Start()
{
	if(m_PlayThread != NULL && m_PlayThread->Suspended())
	{
		m_PlayThread->Resume();
		m_Playing = TRUE;
	}
}

void CBasicPlayer::Stop()
{
	if(m_PlayThread != NULL)
	{
		m_PlayThread->Stop();
		m_SpectrumAnalyserThread->Stop();
		m_Playing = FALSE;
	}
}

long CBasicPlayer::GetLongFramePosition()
{
	m_cs->Enter();
	__int64 pos = DAUDIO_GetBytePosition((void*)m_info, TRUE, m_bytePosition);
	if(pos < 0) pos = 0;
	return (long)(pos / DEFAULT_FRAME_SIZE);
}

void CBasicPlayer::Process(float pFrameRateRatioHint)
{
	if(IsIconic(m_hWnd) == TRUE)
		return;

	for (int a = 0; a < m_SampleSize; a++) {
		m_Left[a] = (m_Left[a] + m_Right[a]) / 2.0f;
	}

	float c = 0;
	float pFrrh = pFrameRateRatioHint;
	float* wFFT = m_FFT->Calculate(m_Left, m_SampleSize);
	float wSadfrr = (m_saDecay * pFrrh);
	float wBw = ((float) m_width / (float) m_saBands);

	RECT rect;
	rect.left = 0;
	rect.top = 0;
	rect.right = rect.left + m_winwidth;
	rect.bottom = rect.top + m_winheight;

	FillRect(m_hdcMem, &rect, m_hbrush);
	for (int a = 0,  bd = 0; bd < m_saBands; a += (INT)m_saMultiplier, bd++) {
		float wFs = 0;
		// -- Average out nearest bands.
		for (int b = 0; b < m_saMultiplier; b++) {
			wFs += wFFT[a + b];
		}

		// -- Log filter.
		wFs = (wFs * (float) log((FLOAT)(bd + 2)));
		//System.out.print(wFs+" ");
		if (wFs > 1.0f) {
			wFs = 1.0f;
		}

		// -- Compute SA decay...
		if (wFs >= (m_oldFFT[a] - wSadfrr)) {
			m_oldFFT[a] = wFs;
		} else {
			m_oldFFT[a] -= wSadfrr;
			if (m_oldFFT[a] < 0) {
				m_oldFFT[a] = 0;
			}
			wFs = m_oldFFT[a];
		}

		drawSpectrumAnalyserBar(&rect, (int) c, m_height, (int) wBw - 1, (int) (wFs * m_height), bd);
		c += wBw;
	}

	BitBlt(m_hdcScreen, 4, 43, m_winwidth, m_winheight, m_hdcMem, 0, 0, SRCCOPY);
}

void CBasicPlayer::drawSpectrumAnalyserBar(RECT* pRect, int pX, int pY, int pWidth, int pHeight, int band)
{
	//TCHAR BUFFER[256];
	//StringCbPrintf(BUFFER, 256, _TEXT("X=%d, Y=%d, Width=%d, Height=%d\n"), pX, pY, pWidth, pHeight);
	//OutputDebugString(BUFFER);

	float c = 0;
	for (int a = pY; a >= pY - pHeight; a -= m_barOffset) {
		pRect->left = pX;
		pRect->right = pRect->left + pWidth;
		pRect->top = a;
		pRect->bottom = pRect->top + 1;
		FillRect(m_hdcMem, pRect, m_hbrush1);
	}

	if (m_peaksEnabled == TRUE) {
		if (pHeight > m_peaks[band]) {
			m_peaks[band] = pHeight;
			m_peaksDelay[band] = m_peakDelay;
		} else {
			m_peaksDelay[band]--;
			if (m_peaksDelay[band] < 0) {
				m_peaks[band]--;
			}
			if (m_peaks[band] < 0) {
				m_peaks[band] = 0;
			}
		}

		pRect->left = pX;
		pRect->right = pRect->left + pWidth;
		pRect->top = pY - m_peaks[band];
		pRect->bottom = pRect->top + 1;
		FillRect(m_hdcMem, pRect, m_hbrush1);
	}
}
