// NewThread.cpp : implementation file
//

#include "stdafx.h"
#include "StudyThread.h"
#include "NewThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewThread

IMPLEMENT_DYNCREATE(CNewThread, CWinThread)

CNewThread::CNewThread()
{
	m_nRecTime=0;
	Buffer=pTotalBuf=NULL;
	m_strState="Ready!";
}

CNewThread::~CNewThread()
{
	if(waveHdr)
		free(waveHdr);
	if(pTotalBuf)
		free(pTotalBuf);
	
}

BOOL CNewThread::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	
	InitSound();

	return TRUE;
}

int CNewThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
if(hWaveIn)
	StopRec();
if(hWaveOut)
	StopPlay();

	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CNewThread, CWinThread)
	//{{AFX_MSG_MAP(CNewThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	ON_THREAD_MESSAGE(MM_WIM_OPEN,ON_WIMOPEN)
	ON_THREAD_MESSAGE(MM_WIM_DATA,ON_WIMDATA)
	ON_THREAD_MESSAGE(MM_WIM_CLOSE,ON_WIMCLOSE)

	ON_THREAD_MESSAGE(MM_WOM_OPEN,ON_WOMOPEN)
	ON_THREAD_MESSAGE(MM_WOM_DONE,ON_WOMDATA)
	ON_THREAD_MESSAGE(MM_WOM_CLOSE,ON_WOMCLOSE)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewThread message handlers

void CNewThread::InitSound()
{
			bRec=false;
			wf.cbSize=0;
			wf.wFormatTag=WAVE_FORMAT_PCM;
			wf.nChannels=1;
			wf.nSamplesPerSec=11025;
			wf.wBitsPerSample =8;
			wf.nBlockAlign=1;
			wf.nAvgBytesPerSec =11025;

			waveHdr=(WAVEHDR*)malloc(sizeof(WAVEHDR));  //Alloc memory for WAVEHDR structure.
}

void CNewThread::StartToRec()
{
				bRec=true;

					uLength=1;
					pTotalBuf=(BYTE *)malloc(uLength*sizeof(BYTE));

					Buffer=(BYTE *)malloc(16384*sizeof(BYTE)); //Alloc memory for buffer.

					waveHdr->lpData=(LPTSTR)Buffer;
					waveHdr->dwBufferLength =16384;
					waveHdr->dwBytesRecorded =0;
					waveHdr->dwUser =0;
					waveHdr->dwFlags =0;
					waveHdr->dwLoops =1;
					waveHdr->lpNext =NULL;
					waveHdr->reserved =0;

				if(MMSYSERR_NOERROR !=::waveInOpen(&hWaveIn,WAVE_MAPPER ,&wf,(DWORD)this->m_nThreadID,NULL,CALLBACK_THREAD))
					{
					//::MessageBox (hWnd,TEXT("Open Device Failed!"),TEXT("System"),MB_OK);
					AfxMessageBox("Open Device Failed!");
					}
				if(MMSYSERR_INVALHANDLE==::waveInPrepareHeader(hWaveIn,waveHdr,sizeof(WAVEHDR)))
					{
				//	::MessageBox (hWnd,TEXT("Prepared Failed!"),TEXT("System"),MB_OK); 
					AfxMessageBox("Prepared Failed!");
				}
				
				if(MMSYSERR_NOERROR!=::waveInAddBuffer (hWaveIn,waveHdr,sizeof(WAVEHDR)))
					{ 
					//::MessageBox (hWnd,TEXT("Add Buffer Failed!"),TEXT("System"),MB_OK); 
					AfxMessageBox("Add Buffer Failed!");
				}

				if( MMSYSERR_NOERROR !=::waveInStart (hWaveIn))
				{
					//::MessageBox (hWnd,TEXT("Record Failed!"),TEXT("System"),MB_OK);
					AfxMessageBox("Record Failed!");
				}

}

void CNewThread::StopRec()
{
					bRec=false;
					::waveInReset (hWaveIn);
					::waveInClose (hWaveIn);
					hWaveIn=NULL;
}

void CNewThread::ON_WIMOPEN(UINT wParam, LONG lParam)
{
	m_strState="Recording...";
}

void CNewThread::ON_WIMDATA(UINT wParam, LONG lParam)
{

	pBuf=(BYTE*)realloc(pTotalBuf,uLength+((PWAVEHDR)lParam)->dwBytesRecorded );
	pTotalBuf=pBuf;
	memcpy(pTotalBuf+uLength,((PWAVEHDR)lParam)->lpData ,((PWAVEHDR)lParam)->dwBytesRecorded);
	uLength+=((PWAVEHDR)lParam)->dwBytesRecorded;
/**/

	if(bRec)
		::waveInAddBuffer (hWaveIn,((PWAVEHDR)lParam),sizeof(WAVEHDR));

}

void CNewThread::ON_WIMCLOSE(UINT wParam, LONG lParam)
{
		::waveInUnprepareHeader (hWaveIn,waveHdr,sizeof(WAVEHDR));
		free(Buffer);
			m_strState="Stop Record";
}

void CNewThread::StartToPlay()
{
::waveOutOpen (&hWaveOut,WAVE_MAPPER,&wf,(DWORD)this->m_nThreadID,NULL,CALLBACK_THREAD);
	
	waveHdr->dwBufferLength =uLength;
	waveHdr->lpData=(LPTSTR)pTotalBuf;
	waveHdr->dwBytesRecorded =0;
	waveHdr->dwUser =0;
	waveHdr->dwFlags =0;
	waveHdr->dwLoops =1;
	waveHdr->lpNext =NULL;
	waveHdr->reserved =0;

	::waveOutPrepareHeader (hWaveOut,waveHdr,sizeof(WAVEHDR));
	::waveOutWrite (hWaveOut,waveHdr,sizeof(WAVEHDR));
}

void CNewThread::ON_WOMOPEN()
{
	m_strState="Playing...";
}

void CNewThread::ON_WOMDATA()
{
	m_strState="Play Finished";
}

void CNewThread::ON_WOMCLOSE()
{
	m_strState="Play Stop!";
}

void CNewThread::StopPlay()
{
	::waveOutUnprepareHeader(hWaveOut,waveHdr,sizeof(WAVEHDR));
	::waveOutClose(hWaveOut);
}

BOOL CNewThread::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	return CWinThread::PreTranslateMessage(pMsg);
}

int CNewThread::GetRecSecond()
{
	if(pTotalBuf&&bRec)
	{
		MMTIME mmTime;
		mmTime.wType =TIME_MS;
    	::waveInGetPosition (hWaveIn,&mmTime,sizeof(MMTIME));

		m_nRecTime=mmTime.u.ms/10000;
	}
	return m_nRecTime;
}

CString CNewThread::GetState()
{
	return m_strState;
}
