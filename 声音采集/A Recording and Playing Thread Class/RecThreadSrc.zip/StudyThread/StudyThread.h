// StudyThread.h : main header file for the STUDYTHREAD application
//

#if !defined(AFX_STUDYTHREAD_H__F6050E06_D12C_4FEA_BC4D_A001C0538B9E__INCLUDED_)
#define AFX_STUDYTHREAD_H__F6050E06_D12C_4FEA_BC4D_A001C0538B9E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CStudyThreadApp:
// See StudyThread.cpp for the implementation of this class
//

class CStudyThreadApp : public CWinApp
{
public:
	CStudyThreadApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStudyThreadApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CStudyThreadApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STUDYTHREAD_H__F6050E06_D12C_4FEA_BC4D_A001C0538B9E__INCLUDED_)
