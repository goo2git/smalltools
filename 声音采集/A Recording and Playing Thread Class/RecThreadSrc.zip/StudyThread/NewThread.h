#if !defined(AFX_NEWTHREAD_H__25C43687_C12A_422B_8E4E_D37FADBCD7D9__INCLUDED_)
#define AFX_NEWTHREAD_H__25C43687_C12A_422B_8E4E_D37FADBCD7D9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NewThread.h : header file
//
#include "mmsystem.h"
#pragma comment(lib,"winmm.lib")

/////////////////////////////////////////////////////////////////////////////
// CNewThread thread

class CNewThread : public CWinThread
{
	DECLARE_DYNCREATE(CNewThread)
public:
	CNewThread();           // protected constructor used by dynamic creation

// Attributes
public:
	virtual ~CNewThread();
// Operations
public:
	CString m_strState;
	CString GetState();


	int GetRecSecond();
	void StopPlay();
	void StartToPlay();


	void StopRec();
	void StartToRec();
private:
	WAVEFORMATEX wf;
	HWAVEIN hWaveIn;
	HWAVEOUT hWaveOut;
	WAVEHDR *waveHdr;
	BYTE *Buffer;
	BYTE *pTotalBuf,*pBuf;
	BOOL bRec;
	UINT uLength;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
protected:


	// Generated message map functions
	//{{AFX_MSG(CNewThread)
afx_msg	void ON_WOMCLOSE();
afx_msg	void ON_WOMDATA();
afx_msg	void ON_WOMOPEN();
afx_msg	void ON_WIMDATA(UINT wParam, LONG lParam);
afx_msg	void ON_WIMOPEN(UINT wParam, LONG lParam);
afx_msg	void ON_WIMCLOSE(UINT wParam, LONG lParam);

		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	UINT m_nRecTime;
	void InitSound();
	

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEWTHREAD_H__25C43687_C12A_422B_8E4E_D37FADBCD7D9__INCLUDED_)
