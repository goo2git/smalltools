//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by multiplayer.rc
//
#define IDC_PLAYALL                     3
#define IDC_STOPALL                     4
#define IDC_BTNRESET                    5
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MULTIPLAYER_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDM_MENU                        129
#define IDC_LISTEVENT                   1000
#define IDC_COMBOPLAYLIST               1001
#define IDC_BTNNORMAL                   1004
#define IDC_BTNFADEIN                   1005
#define IDC_BTNFADEOUT                  1006
#define IDC_BTNPLAYNORMAL               1007
#define IDC_BTNPLAYLOOP                 1008
#define IDC_SPIN1                       1009
#define IDC_SPINSPEED                   1009
#define IDC_BTNPLAY                     1010
#define IDC_BTNSTOP                     1011
#define IDC_SPINVOLUME                  1012
#define IDC_SPINLEFT                    1013
#define IDC_SPINRIGHT                   1014
#define IDC_BTNPANCENTER                1015
#define IDC_BTNSPEEDUP                  1016
#define IDC_BTNSPEEDDOWN                1017
#define IDC_BTNVOLUMEUP                 1018
#define IDC_BTNVOLUMEDOWN               1019
#define IDC_BTNLEFTUP                   1020
#define IDC_BTNLEFTDOWN                 1021
#define IDC_BTNRIGHTUP                  1022
#define IDC_BTNRIGHTDOWN                1023
#define IDM_FILEOPEN                    32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
