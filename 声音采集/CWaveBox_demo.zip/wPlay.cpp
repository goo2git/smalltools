// wPlay.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "wavebox.h"
#include <stdio.h>
#include <conio.h>

int main(int argc, char* argv[])
{
    CWaveBox w;

    /// load waves
    w.Load("twilightzone.wav");
    w.Load("badfeeling.wav");
    w.Load("wolfcall.wav");
    w.Load("heart.wav");
    w.Load("gusting_winds.wav");
    w.Load("newmail.wav");
    w.Load("dumbass.wav");
    w.Load("porky.wav");
    w.Load("system_alert.wav");
  
	printf("<CWaveBox v0.95 demo>:\n\n");
    printf("You will listen 9 waves in this demo, approx. 30 sec.\n");

    /// and play with them ;-)
    for( int f = 0; f < 5; f++ ){ w.Play(8); Sleep(50); } Sleep(2000);
    for( f = 0; f < 5; f++ ){ w.Play(8); Sleep(75);}

    for( int k = 0; k < 1000; k += 50 )
    {
        w.Play(3); Sleep( 300 + 1000 - k );

        if( !( k % 200 ) )          w.Play(2);
        if( k == 400 || k == 700 )  w.Play(1);

        if( k == 950 )
        { w.Play(4); Sleep( 500 );}
    }

    w.Play(0);Sleep(2500);
    w.Play(5);Sleep(1500);
    w.Play(6);Sleep(4500);
    w.Play(7);
    
    printf("thats all folks! ;-) \n");  
    getch();

    return 1;
}
