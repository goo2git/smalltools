using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using AudioUtils;

namespace ShowWaveForm
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem file;
		private System.Windows.Forms.MenuItem fileOpen;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		
		WaveFile wave;
		StatusBarPanel sbpMainPanel;
		bool m_DrawWave = false;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			
			BackColor = SystemColors.Window;
			ForeColor = SystemColors.WindowText;
			ResizeRedraw = true;

			StatusBar sb = new StatusBar();
			sb.Parent = this;
			sb.ShowPanels = true;
			
			sbpMainPanel = new StatusBarPanel( );
			sbpMainPanel.Text = "Ready";
			sbpMainPanel.AutoSize = StatusBarPanelAutoSize.Spring;

			sb.Panels.Add( sbpMainPanel );
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.file = new System.Windows.Forms.MenuItem();
			this.fileOpen = new System.Windows.Forms.MenuItem();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.file});
			// 
			// file
			// 
			this.file.Index = 0;
			this.file.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				 this.fileOpen});
			this.file.Text = "&File";
			// 
			// fileOpen
			// 
			this.fileOpen.Index = 0;
			this.fileOpen.Text = "&Open";
			this.fileOpen.Click += new System.EventHandler(this.fileOpen_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(896, 437);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "ShowWaveForm";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void fileOpen_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog fileDlg = new OpenFileDialog();

			if ( fileDlg.ShowDialog() == DialogResult.OK )
			{
				wave = new WaveFile( fileDlg.FileName );

				sbpMainPanel.Text = "Reading .WAV file...";

				wave.Read( );

				sbpMainPanel.Text = "Finished Reading .WAV file...";

				m_DrawWave = true;

				Refresh( );

			}
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Pen pen = new Pen( ForeColor );

			if ( m_DrawWave )
			{
				sbpMainPanel.Text = "Drawing .WAV file...";

				wave.Draw( e, pen );

				sbpMainPanel.Text = "Finished drawing .WAV file...";
			}
		}

		protected override void OnMouseWheel( MouseEventArgs mea )
		{
			if ( mea.Delta * SystemInformation.MouseWheelScrollLines / 120 > 0 )
				wave.ZoomIn( );
			else
				wave.ZoomOut( );

			Refresh( );
		}

	}
}
