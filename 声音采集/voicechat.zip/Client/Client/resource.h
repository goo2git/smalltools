//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDD_DIALOG1                     101
#define IDD_DIALOG2                     102
#define IDB_BITMAP1                     103
#define IDI_ICON1                       104
#define IDB_BITMAP2                     105
#define IDD_DIALOG3                     106
#define IDD_DIALOG4                     107
#define IDD_DIALOG5                     108
#define IDB_BITMAP3                     109
#define IDB_BITMAP4                     110
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_BUTTON1                     1003
#define IDC_COMBO1                      1004
#define IDC_BUTTON2                     1005
#define IDC_LIST1                       1006
#define IDC_RADIO1                      1007
#define IDC_RADIO2                      1008
#define IDC_BUTTON5                     1009
#define IDC_BUTTON6                     1010
#define IDC_BUTTON3                     1012
#define IDC_SLIDER1                     1013
#define IDC_SLIDER2                     1014
#define IDC_ANIMATE1                    1014
#define IDC_BUTTON4                     1016
#define IDC_ANIMATE2                    1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
