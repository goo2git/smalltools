// myapp.h: interface for the myapp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYAPP_H__33C94243_415D_11D6_8886_200654C10000__INCLUDED_)
#define AFX_MYAPP_H__33C94243_415D_11D6_8886_200654C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class myapp : public CWinApp  
{
public:
BOOL InitInstance();
};

#endif // !defined(AFX_MYAPP_H__33C94243_415D_11D6_8886_200654C10000__INCLUDED_)
