// myapp.h: interface for the myapp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYAPP_H__73FA8623_4122_11D6_8886_801654C10000__INCLUDED_)
#define AFX_MYAPP_H__73FA8623_4122_11D6_8886_801654C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class myapp : public CWinApp  
{
public:
	BOOL InitInstance();
};

#endif // !defined(AFX_MYAPP_H__73FA8623_4122_11D6_8886_801654C10000__INCLUDED_)
