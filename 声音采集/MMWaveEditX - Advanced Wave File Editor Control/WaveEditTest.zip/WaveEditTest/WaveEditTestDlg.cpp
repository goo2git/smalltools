// WaveEditTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WaveEditTest.h"
#include "WaveEditTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWaveEditTestDlg dialog

CWaveEditTestDlg::CWaveEditTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWaveEditTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWaveEditTestDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CWaveEditTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWaveEditTestDlg)
	DDX_Control(pDX, IDC_PROGRESS1, m_Progress);
	DDX_Control(pDX, IDC_STATICMSG, m_stcMsg);
	DDX_Control(pDX, IDC_SCROLLBAR1, m_scrBar);
	DDX_Control(pDX, IDC_MMWAVEEDITXCTRL1, m_WaveEditor);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CWaveEditTestDlg, CDialog)
	//{{AFX_MSG_MAP(CWaveEditTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTONIN, OnButtonin)
	ON_BN_CLICKED(IDC_BUTTONOUT, OnButtonout)
	ON_BN_CLICKED(IDC_BUTTONOPEN, OnButtonopen)
	ON_WM_VSCROLL()
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWaveEditTestDlg message handlers

BOOL CWaveEditTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	m_Progress.SetRange(0,100);
	m_WaveEditor.EnableWindow(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CWaveEditTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CWaveEditTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CWaveEditTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CWaveEditTestDlg::OnButtonin() 
{
	m_WaveEditor.ZoomIn();
	long lLow;
	long lHigh;	
	m_WaveEditor.GetScrollRanges(&lLow,&lHigh);
	m_scrBar.SetScrollRange(lLow,lHigh);
	m_scrBar.SetScrollPos(lLow);

}

void CWaveEditTestDlg::OnButtonout() 
{
	m_WaveEditor.ZoomOut();
	long lLow;
	long lHigh;	
	m_WaveEditor.GetScrollRanges(&lLow,&lHigh);
	m_scrBar.SetScrollRange(lLow,lHigh);
	m_scrBar.SetScrollPos(lLow);
	
}

void CWaveEditTestDlg::OnButtonopen() 
{
	CFileDialog dlg(TRUE);

	if(dlg.DoModal() == IDOK)
	{
		long lLow;
		long lHigh;
		
		m_WaveEditor.EnableWindow(TRUE);
		m_WaveEditor.LoadWaveFile(dlg.GetPathName());
		m_WaveEditor.GetScrollRanges(&lLow,&lHigh);

		m_scrBar.SetScrollRange(lLow,lHigh);
		m_scrBar.SetScrollPos(lLow);

		Invalidate(TRUE);
	}
}

void CWaveEditTestDlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default

	CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}

BEGIN_EVENTSINK_MAP(CWaveEditTestDlg, CDialog)
    //{{AFX_EVENTSINK_MAP(CWaveEditTestDlg)
	ON_EVENT(CWaveEditTestDlg, IDC_MMWAVEEDITXCTRL1, 1 /* Message */, OnMessageMmwaveeditxctrl1, VTS_BSTR)
	ON_EVENT(CWaveEditTestDlg, IDC_MMWAVEEDITXCTRL1, 2 /* ProgressIndicator */, OnProgressIndicatorMmwaveeditxctrl1, VTS_I4)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CWaveEditTestDlg::OnMessageMmwaveeditxctrl1(LPCTSTR sMsg) 
{
	m_stcMsg.SetWindowText(sMsg);
	
}

void CWaveEditTestDlg::OnProgressIndicatorMmwaveeditxctrl1(long lProgress) 
{
	m_Progress.SetPos(lProgress);
	
}

void CWaveEditTestDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	if(pScrollBar->GetSafeHwnd() == m_scrBar.GetSafeHwnd())
	{

	   // Get the minimum and maximum scroll-bar positions.
	   int minpos;
	   int maxpos;
	   pScrollBar->GetScrollRange(&minpos, &maxpos); 
	   maxpos = pScrollBar->GetScrollLimit();

	   // Get the current position of scroll box.
	   int curpos = pScrollBar->GetScrollPos();

	   // Determine the new position of scroll box.
	   switch (nSBCode)
	   {
	   case SB_LEFT:      // Scroll to far left.
		  curpos = minpos;
		  break;

	   case SB_RIGHT:      // Scroll to far right.
		  curpos = maxpos;
		  break;

	   case SB_ENDSCROLL:   // End scroll.
		  break;

	   case SB_LINELEFT:      // Scroll left.
		  if (curpos > minpos)
			 curpos--;
		  break;

	   case SB_LINERIGHT:   // Scroll right.
		  if (curpos < maxpos)
			 curpos++;
		  break;

	   case SB_PAGELEFT:    // Scroll one page left.
	   {
		  // Get the page size. 
		  SCROLLINFO   info;
		  pScrollBar->GetScrollInfo(&info, SIF_ALL);

		  if (curpos > minpos)
		  curpos = max(minpos, curpos - (int) info.nPage);
	   }
		  break;

	   case SB_PAGERIGHT:      // Scroll one page right.
	   {
		  // Get the page size. 
		  SCROLLINFO   info;
		  pScrollBar->GetScrollInfo(&info, SIF_ALL);

		  if (curpos < maxpos)
			 curpos = min(maxpos, curpos + (int) info.nPage);
	   }
		  break;

	   case SB_THUMBPOSITION: // Scroll to absolute position. nPos is the position
		  curpos = nPos;      // of the scroll box at the end of the drag operation.
		  break;

	   case SB_THUMBTRACK:   // Drag scroll box to specified position. nPos is the
		  curpos = nPos;     // position that the scroll box has been dragged to.
		  break;
	   }

	   m_WaveEditor.ScrollToPosition(curpos);
	   // Set the new position of the thumb (scroll box).
	   pScrollBar->SetScrollPos(curpos);

	}
	
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}
