#if !defined(AFX_MMWAVEEDITXCTL_H__02DAA672_4ABB_11D3_9A58_0080C605ADA4__INCLUDED_)
#define AFX_MMWAVEEDITXCTL_H__02DAA672_4ABB_11D3_9A58_0080C605ADA4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// MMWaveEditXCtl.h : Declaration of the CMMWaveEditXCtrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CMMWaveEditXCtrl : See MMWaveEditXCtl.cpp for implementation.
#include "CEditWaveFile.h"
#include "BmpDC.h"
#include < MSStkPPg.H > 
class CMMWaveEditXCtrl : public COleControl
{
	DECLARE_DYNCREATE(CMMWaveEditXCtrl)

// Constructor
public:
	CMMWaveEditXCtrl();

	// Variables
	BOOL				m_bInitialized;
	BOOL				m_bCursorOn;
	BOOL				m_bLButtonDown;

	BOOL				m_bRightDrag;
	BOOL				m_bLeftDrag;
	BOOL				m_bDraggingSelection;

	BOOL				m_bPlayingCursVisible;

	CRect				m_rcLastCursorPos;
	CRect				m_rcLastSelectRect;
	CRect				m_rcLastPlayingPos;

	UINT				m_nTimer;

	CEditWaveFile		m_WaveFile;


// Property Vars

	COLORREF	clr_Waveform;	
	COLORREF	clr_DB;
	COLORREF	clr_Divider;
	COLORREF	clr_ScaleBackround;
	COLORREF	clr_ScaleTicks;
	COLORREF	clr_ScaleNumbers;
	COLORREF	clr_TrackBack;
	COLORREF	clr_TrackPen;

	long		m_lMinTickSize;
	long		m_lMajTickSize;
	long		m_lMinTickInterval;
	long		m_lMajTickInterval;
	long		m_lScaleHeight;
	long		m_lTrackerHeight;

	// Funcs
	void		StartTheTimer		();
	void		StopTheTimer		();
	void		DrawCursor			();


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMMWaveEditXCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CMMWaveEditXCtrl();

	DECLARE_OLECREATE_EX(CMMWaveEditXCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CMMWaveEditXCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CMMWaveEditXCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CMMWaveEditXCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CMMWaveEditXCtrl)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CMMWaveEditXCtrl)
	afx_msg OLE_COLOR GetWaveform();
	afx_msg void SetWaveform(OLE_COLOR nNewValue);
	afx_msg OLE_COLOR GetDB();
	afx_msg void SetDB(OLE_COLOR nNewValue);
	afx_msg OLE_COLOR GetDivider();
	afx_msg void SetDivider(OLE_COLOR nNewValue);
	afx_msg OLE_COLOR GetScaleBackround();
	afx_msg void SetScaleBackround(OLE_COLOR nNewValue);
	afx_msg OLE_COLOR GetScaleTicks();
	afx_msg void SetScaleTicks(OLE_COLOR nNewValue);
	afx_msg OLE_COLOR GetScaleNumbers();
	afx_msg void SetScaleNumbers(OLE_COLOR nNewValue);
	afx_msg long GetMinTickSize();
	afx_msg void SetMinTickSize(long nNewValue);
	afx_msg long GetMajTickSize();
	afx_msg void SetMajTickSize(long nNewValue);
	afx_msg long GetMajTickInterval();
	afx_msg void SetMajTickInterval(long nNewValue);
	afx_msg long GetScaleHeight();
	afx_msg void SetScaleHeight(long nNewValue);
	afx_msg long GetMinTickInterval();
	afx_msg void SetMinTickInterval(long nNewValue);
	afx_msg long GetTrackerHeight();
	afx_msg void SetTrackerHeight(long nNewValue);
	afx_msg OLE_COLOR GetTrackBack();
	afx_msg void SetTrackBack(OLE_COLOR nNewValue);
	afx_msg OLE_COLOR GetTrackPen();
	afx_msg void SetTrackPen(OLE_COLOR nNewValue);
	afx_msg void LoadWaveFile(LPCTSTR sWave);
	afx_msg long GetCurrentZoomScale();
	afx_msg float GetFileLengthInSeconds();
	afx_msg void GetScrollRanges(long FAR* lpLow, long FAR* lpHigh);
	afx_msg void ZoomIn();
	afx_msg void ZoomOut();
	afx_msg void ScrollToPosition(long lValue);
	afx_msg long GetCurFilePosition();
	afx_msg void SetPlayingPosition(long lPosition);
	afx_msg void GetCurSelectionRange(long FAR* lStartPos, long FAR* lEndPos);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
public:
// Event maps
	//{{AFX_EVENT(CMMWaveEditXCtrl)
	void FireMessage(LPCTSTR sMsg)
		{FireEvent(eventidMessage,EVENT_PARAM(VTS_BSTR), sMsg);}
	void FireProgressIndicator(long lProgress)
		{FireEvent(eventidProgressIndicator,EVENT_PARAM(VTS_I4), lProgress);}
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CMMWaveEditXCtrl)
	dispidWaveform = 1L,
	dispidDB = 2L,
	dispidDivider = 3L,
	dispidScaleBackround = 4L,
	dispidScaleTicks = 5L,
	dispidScaleNumbers = 6L,
	dispidMinTickSize = 7L,
	dispidMajTickSize = 8L,
	dispidMajTickInterval = 9L,
	dispidScaleHeight = 10L,
	dispidMinTickInterval = 11L,
	dispidTrackerHeight = 12L,
	dispidTrackBack = 13L,
	dispidTrackPen = 14L,
	dispidLoadWaveFile = 15L,
	dispidGetCurrentZoomScale = 16L,
	dispidGetFileLengthInSeconds = 17L,
	dispidGetScrollRanges = 18L,
	dispidZoomIn = 19L,
	dispidZoomOut = 20L,
	dispidScrollToPosition = 21L,
	dispidGetCurFilePosition = 22L,
	dispidSetPlayingPosition = 23L,
	dispidGetCurSelectionRange = 24L,
	eventidMessage = 1L,
	eventidProgressIndicator = 2L,
	//}}AFX_DISP_ID
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MMWAVEEDITXCTL_H__02DAA672_4ABB_11D3_9A58_0080C605ADA4__INCLUDED)
